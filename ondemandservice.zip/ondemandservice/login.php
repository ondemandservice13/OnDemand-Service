<?php require('core/init.php') ?>

<?php

$post = new Post();

$template = new Template('template/login.php');

echo $template;

if(isset($_POST['do_login'])){
    $data = array();

    $data['email'] = $_POST['email'];
    $data['pass'] = md5($_POST['pass']);
     
     $user = new User(); 

     
    if($user->login($data)){
      redirect('verification.php','Your successfully registered !!','success');
    }else{
      redirect('login.php',' Wrong Inputs or Please verify your email ! ',' error ');
    }

}
?>