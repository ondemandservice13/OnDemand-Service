<?php require('core/init.php') ?>

<?php
 

$user = new User();

$post = new Post();


$poststatus = new PostStatus();
 
if($_GET['a'] == 'c'){


	$u_id = $_GET['u_id'];
	$p_id = $_GET['p_id'];

   $user = $user->getUserInfo($u_id);
   $post = $post->getPostDetails($p_id);

   $data = array();
   $data['creator'] = getUser()['name'];
   $data['p_title'] = $post->p_title;
   $data['p_id'] = $post->p_id;
   $data['email'] = $user->email;

   echo $data['email'];
   acceptPostSeeker($data);

	if($poststatus->confirmSeeker($u_id,$p_id)){
		if($poststatus->deleteSeeker($u_id,$p_id)){
      redirect('postdetails.php','Seeker is confirmed','success');
  }
    }else{
      redirect('postdetails.php','Seeker is not confirmed !!','error');
    }


}

if($_GET['a'] == 'd'){
	$u_id = $_GET['u_id'];
	$p_id = $_GET['p_id'];


   $user = $user->getUserInfo($u_id);
   $post = $post->getPostDetails($p_id);

   $data = array();
   $data['p_title'] = $post->p_title;
   $data['p_id'] = $post->p_id;
   $data['s_email'] = $user->email;
   $data['user_id'] = $u_id;
   $data['p_email'] = $post->email;

   //echo $data['email'];
   jobDone($data);

	if($poststatus->updateCompletionDate($u_id,$p_id)){
		redirect('postdetails.php','Task Complete','success');
    }else{
      redirect('postdetails.php','Error','error');
    }
}

if($_GET['a'] == 'u'){
	if($_SESSION['user_id'] != $_GET['u_id']){ 

	$_SESSION['u_id'] = $_GET['u_id'];

	if(is_null($_SESSION['id'])){
	$_SESSION['id'] = $_GET['id'];

	}

 	redirect('postdetails.php','','');
    }else{
    	redirect('index.php','','');
    }
}


if($_GET['a'] == 'e'){
	$user_id = $_GET['u_id'];
	if($user->updateVerification($user_id)){
		redirect('verification.php','Task Complete','success');
	}
}

if($_GET['a'] == 'f'){
	$data['user_id'] = $_GET['u_id'];
	$data['otp'] = $_GET['otp'];

	if($user->checkOtp($data)){

		redirect('resetpassword.php?u_id='.$data['user_id'].'','Email verified !' ,'success');
	
   }else{
   		redirect('resetpassword.php#about','incorrect otp','error');
   }

}

if($_GET['a'] == 'r'){
  $data['p_id'] = $_GET['p_id'];
  $data['u_id'] = getUser()['user_id'];
  if($post->deletePost($data)){

    redirect('userposts.php?category=user_posts','Post is removed' ,'success');
  
   }else{
      redirect('userposts.php?category=user_posts','Post removal is unsuccessful','error');
   }

}

   

