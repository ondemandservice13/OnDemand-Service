<?php require('core/init.php') ?>


<?php
$user = new User();

$user_id = getUser()['user_id'];


$verify = $user->getUserInfo($user_id);
$email = $verify->email;



if($verify->verify == 1){
      redirect('userposts.php?category=all','Your Logged In !!!','success');
}else{

emailVerification($email,$user_id);		
$template = new Template('template/verifyemail.php');

echo $template;

}
?>