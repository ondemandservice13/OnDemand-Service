<?php require('core/init.php') ?>

<?php

  $user = new User();

if(isset($_POST['signup'])){


    $data = array();

    $data['fname'] = $_POST['fname'];
    $data['lname'] = $_POST['lname'];
    $data['phone'] = $_POST['phone'];    
    $data['contry'] = $_POST['contry'];
    $data['state'] = $_POST['state'];    
    $data['district'] = $_POST['district'];
    $data['city'] = $_POST['city'];
    $data['address'] = $_POST['address'];
    $data['pincode'] = $_POST['pincode'];
    $data['gender'] = $_POST['gender'];
    $data['dob'] = $_POST['dob'];
    $data['email'] = $_POST['email'];
    $data['pass'] = md5($_POST['pass']);
    $cpass = md5($_POST['cpass']); 
    if($data['pass'] == $cpass){

    if($user->checkEmail($data['email'])){

    if($user->register($data)){

      redirect('verification.php','Your successfully registered !!','success');

    }else{
      redirect('sign_up.php','Your unable to registered !!','error');
    }

}else{
    redirect('sign_up.php','Email already exist','error');
}

}else{
    redirect('sign_up.php','Password not match','error');
}

}

$template = new Template('template/sign_up.php');

echo $template;

?>