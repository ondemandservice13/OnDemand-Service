<?php require('core/init.php') ?>

<?php


$user = new User();

$post = new Post();
 

    if($user->logOut()){
      redirect('login.php','your Logged Out !!','success');
    }else{
      redirect('profile.php');
    }


?>