 <!DOCTYPE html>
<html lang="en">
<head>
  <title>OnDemandService</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
<style type="text/css">
  #reg-forms button[type="submit"]{
     padding-top: 10px;
     padding-bottom: 10px;
     padding-right: 50px;
     padding-left: 50px;
      margin-top:10px; 
     align-content: center;
      }
  #reg-forms input[type="password"]{ margin-top:10px; }
      
  #reg-forms{
     margin-top: 70px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  #reg-forms form {
    padding: 15px;
    margin: 10;
}
#reg-forms .form-control {
    position: relative;
    box-sizing: border-box;
    height: auto;
    padding: 10px;
    font-size: 16px;
}

.nav{
      font-size:13px;  padding-left:70px; padding-right:50px; 
    }
  @media screen and (max-width: 768px) {
    .nav {
      padding-right:5px;
    }
    
</style>
</head>
<body>
<?php include('includes/loginheader.php') ?>
<div class="col-sm-4"></div>
<div class="col-sm-4">
<div class="panel panel-primary" id="reg-forms" class="well"  >

<?php  if(isLoggedIn()) : ?>
          <form class = "form-login" method = "POST" action = "log_out.php">
          <h1 class="h3 mb-3 font-weight-normal" style="text-align: center"> 
              Welcome <a href="profile.php"><?php echo getUser()['name']; ?> </a>
          </h1>
          <button class="btn btn-success btn-block" name="do_loggedOut" type="submit"><i class="fas fa-sign-in-alt"></i> Log Out</button>
        </form>
         <?php else : ?> 
        <form class="form-login" method="POST" action="login.php">
          <?php displayMessage(); ?>
            <h1 class="h3 mb-3 font-weight-normal" style="text-align: center"> Log in</h1>
            <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required="" autofocus="">
           <input type="password" id="pass" name="pass" class="form-control" placeholder="Password" required autofocus="">
            
            <button class="btn btn-success btn-block" name="do_login" type="submit"><i class="fas fa-sign-in-alt"></i> Log in</button>
              </form>
            <a href="forgetpassword.php" id="forgot_pswd">Forgot password?</a>
            
            <!-- <p>Don't have an account!</p>  -->

            <form class="sign_up" method="post" action="sign_up.php">
            <button class="btn btn-primary btn-block" type="submit" id="btn-signup" name='login'><i class="fas fa-user-plus"></i> Sign up New Account</button>
          </form>
        <?php endif; ?>

</div> </div>
</body>
</html>