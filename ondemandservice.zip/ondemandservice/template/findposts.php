<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  .panel{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }

input[type=text] {
  width: 330px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 20px 12px 40px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 100%;
}
#l{
  white-space: nowrap; 
  width: 300px; 
  overflow: hidden;
  text-overflow: ellipsis;
}

</style>

</head>
<body>

<?php include('includes/findpostheader.php') ?>

<div id="main">
<div class="profile-container bootstrap snippet">
    <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      <div class="col-sm-1"></div>
    </div>

  <div class="row">
            <div class="col-sm-1" style="margin-right: 50px;"></div>
            <div class="col-sm-9" style="margin-left: 10px;">
             <input class="" id="myInput" type="text" placeholder="Search by task, location, price..."></div>
           </div>

    <div class="row" style="margin-left: 5px">
      <div class="col-sm-1"><!--left col-->
         </div>           
          <div class="col-sm-10">
            <hr>

            <form class="form" action="" method="POST" id="">
                      <div class="form-group">
                          <div class="container">    
                            <div class="row">
                              <?php if($allposts) : ?>
                                
                                <?php foreach ($allposts as $post) : ?>
                                <?php if($post->accept_date == null and $post->applyby != getUser()['user_id']) :?>   
                                <div class="col-sm-4">
                                    <div class="panel panel-primary">
                                      <div class="panel-heading"><?php echo $post->p_title; ?></div>
                                         <div class="panel-body">
                                              
                                              <label id="l">Discription:- <?php echo $post->p_desc; ?> </label><br>
                                              <label id="l">Location:- <?php echo $post->loc; ?> </label><br>
                                              <label>Price:- <?php echo $post->stipend; ?> </label><br>
                                              <label id="d">Created On:- <?php echo $post->c_date; ?> </label><br>
                                          </div>

                                      <div class="panel-footer">
                                        <a href="findpostdetails.php?id=<?php echo $post->p_id; ?>" >More Details </a></div>
                                     </div>
                                    </div>
                                  <?php endif; ?>
                                 <?php endforeach; ?>                                                       
                               <?php else : ?>
                               <h3><i>No Post for <?php echo $user->firstName ?></i></h3> 
                              <?php endif; ?>  
                            </div>
                       </div><br>
                       </div>
                  </form>
                 
              </div>
            </div>
          </div>
              

          </div>
        

<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $(".col-sm-4 ").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>                                  
   </body></html>                                          