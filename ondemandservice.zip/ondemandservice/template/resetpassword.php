<!DOCTYPE html>
<html lang="en">
<head>
  <title>OnDemandService</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
<style type="text/css">
  #reg-forms button[type="submit"]{
     padding-top: 10px;
     padding-bottom: 10px;
     padding-right: 50px;
     padding-left: 50px;
     align-content: center;
      }
  #reg-forms{
     margin-top: 100px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  #reg-forms form {
    padding: 15px;
    margin: 10;
}
#logreg-forms .form-control {
    position: relative;
    box-sizing: border-box;
    height: auto;
    padding: 10px;
    font-size: 16px;
}
.nav{
      font-size:13px;  padding-left:70px; padding-right:50px; 
    }
  @media screen and (max-width: 768px) {
    .nav {
      padding-right:5px;
    }

</style>
</head>
<body>

<?php include('includes/header.php') ?>
<br><br>
<div class="">
  <div class="col-sm-4"></div>
  <div class="col-sm-4">
     <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      <div class="col-sm-1"></div>
    </div>

<div class="panel panel-primary" style="margin: 40px;">
  <div class="panel-heading">
   <h3 class="font-weight-normal" style="text-align: center;" >Reset Your Password</h3>
 </div>
  <div class="panel-body">
   <form method="post">
    <input type="Password" id="password" name="password" class="form-control" placeholder="New Password" required autofocus=""><br>
    <input type="Password" id="c_password" name="c_password" class="form-control" placeholder="Confirm Password" required autofocus="">
    <br>
    <button class="btn btn-primary" name="reset" >Reset</button> 
   </form>   
   </div> 
  </div>
</div>
</div>
</div>

</body>
</html>




          














           
           
           
           
           
           
