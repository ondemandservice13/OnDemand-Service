

<nav class="navbar navbar-default">
  <div class="">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">On-Demand Service</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right ">
       <li class="active"><a href="createpost.php">Create Post</a></li>
      <li><a href="userposts.php?category=all">User Tasks</a></li>
      <li><a href="findposts.php">Find Task</a></li>      
      <li><a href="profile.php">Profile</a></li> 
      <li><a href="log_out.php"><span class="glyphicon glyphicon-lock"></span> Log Out</a></li>
    </ul>
  </div></div>
</nav>

