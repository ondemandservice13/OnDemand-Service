<nav class="navbar navbar-default navbar-fixed-top">
  <div class="nav" style="">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">On-Demand Service</a>
    </div>
    <div class="collapse navbar-collapse navbar-fixed" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li ><a href="index.php#services">How It Works</a></li>
        <li ><a href="index.php#pricing">Tasks</a></li>
        <li ><a href="index.php#contact">Contact</a></li>

       <?php  if(isLoggedIn()) : ?>
          <li><a href="verification.php">Profile</a></li>
          <li><a href="log_out.php"><span class="glyphicon glyphicon-lock"></span> Log Out</a></li>
      <?php else : ?> 
         <li class="active"><a href="login.php">Log-In</a></li>
         <li><a href="sign_up.php">Sign-Up</a></li>
      <?php endif; ?>   
      </ul>
  </div></div>
</nav>
<script type="text/javascript">
  var btns =document.querySelectorAll('li');
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
  var current = document.getElementsByClassName("active");
  if (current.length > 0) { 
    current[0].className = current[0].className.replace(" active", "");
  }
  this.className += " active";
  });
}

</script>