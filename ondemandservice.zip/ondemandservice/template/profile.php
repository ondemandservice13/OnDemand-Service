<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  
</style>

</head>
<body class="bg-light">


<?php include('includes/profile_hrader.php') ?>



<hr>
<div class="profile-container bootstrap snippet">
    <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      
    </div>
          <div class = "row">
            <div class="col-sm-8">
            <div class="panel panel-info" style="margin: 25px; margin-top:50px; ">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >User Details</h1> 
                               </div>
                               <div class="panel-body bg-warning">
            
                  <form class="form" action="" method="post" id="registrationForm">
                    <?php if(isset($_POST['edit'])) : ?>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                              <label for="first_name"><h4>First Name :</h4></label>
                              <input type="text" class="form-control" name="fname" id="first_name" value="<?php echo $user->firstName ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                            <label for="last_name"><h4>Last Name :</h4></label>
                              <input type="text" class="form-control" name="lname" id="last_name" value="<?php echo $user->lastName ?>">
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-8">
                              <label for="address"><h4>Address :</h4></label>
                              <input type="text" class="form-control" name="address" value="<?php echo $user->address ?>">
                          </div>
                          
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-8">
                             <label for="mobile"><h4>Mobile :</h4></label>
                              <input type="text" class="form-control" name="mobile" id="mobile" value="<?php echo $user->mobile ?>" >
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                              <label for="email"><h4>Email :</h4></label>
                              <input type="email" class="form-control" name="email" id="email" value="<?php echo $user->email ?>">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                              <label for="dob"><h4>Date of Birth</h4></label>
                              <input type="date" class="form-control" name="dob" id="dob" value="<?php echo $user->dob ?>" title="enter your password.">
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-xs-8">
                              <label for="phone"><h4>Gender</h4></label><br>
                               <?php if($user->gender == 'Male') : ?>
                               <input type="radio" name="gender" value="Male" style="margin-left: 50px;" checked="checked" > Male
                               <input type="radio" name="gender" value="Female" style="margin-left: 50px;"> Female
                               <?php else : ?>
                               <input type="radio" name="gender" value="Male" style="margin-left: 50px;"> Male
                               <input type="radio" name="gender" value="Female" style="margin-left: 50px;" checked="checked"> Female
                               <?php endif; ?> 
                          </div>
                          
                      </div>
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success" name="save" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
                            </div>
                      </div>
                    <?php else : ?>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                              <label for="first_name"><h4>First Name : <?php echo $user->firstName ?> </h4></label>
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                            <label for="last_name"><h4>Last Name : <?php echo $user->lastName ?></h4></label>
                          
                          </div>
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-8">
                              <label for="address"><h4>Address : <?php echo $user->address ?></h4></label>
                             
                          </div>
                          
                      </div>
          
                      <div class="form-group">
                          <div class="col-xs-8">
                             <label for="mobile"><h4>Mobile : <?php echo $user->mobile ?></h4></label>
                             
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                              <label for="email"><h4>Email : <?php echo $user->email ?></h4></label>
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-8">
                              <label for="dob"><h4>Date of Birth : <?php echo $user->dob ?></h4></label>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-xs-8">
                              <label for="phone"><h4>Gender : <?php echo $user->gender ?></h4></label>
                              
                          </div>
                        </div>
                        <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                              <button class="btn btn-lg btn-primary" name="edit" type="submit">Edit</button>
                            </div>
                      </div>
                      <?php endif; ?>
                      
                </form>
              </div></div>
            </div>
            <div class="col-sm-4">

            <div class="panel panel-info" style="margin: 25px; margin-top: 50px">
              <div class = " panel-heading">                
                 <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >User Activity</h1> 
              </div>
              <div class = "panel-body bg-warning" style="padding: 50px">
                 <ul class="list-group" style="padding: 10px">
            <li class="list-group-item text-muted " style="background-color: YELLOW;font-weight:bolder; color: black ">Post Activity <i class="fa fa-dashboard fa-1x"></i></li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Created</strong></span> 125</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Accepted</strong></span> 13</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Pending</strong></span> 37</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Active</strong></span> 78</li>
            <li class="list-group-item text-right"><span class="pull-left"><strong>Completed</strong></span> 78</li>
          </ul> 
            </div>
            </div>
            </div> 
            </div> 
            </div> 
                                
   </body></html>                                          