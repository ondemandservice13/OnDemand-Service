<!DOCTYPE html>
<html lang="en">
<head>
  <title>OnDemandService</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
<style type="text/css">
  #reg-forms button[type="submit"]{
     padding-top: 10px;
     padding-bottom: 10px;
     padding-right: 50px;
     padding-left: 50px;
     align-content: center;
      }
  #reg-forms{
     margin-top: 70px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  #reg-forms form {
    padding: 15px;
    margin: 10;
}
#logreg-forms .form-control {
    position: relative;
    box-sizing: border-box;
    height: auto;
    padding: 10px;
    font-size: 16px;
}
.nav{
      font-size:13px;  padding-left:70px; padding-right:50px; 
    }
  @media screen and (max-width: 768px) {
    .nav {
      padding-right:5px;
    }

</style>
</head>
<body>
<?php include('includes/signupheader.php') ?>
<div class="col-sm-1"></div>
<div class="col-sm-10">
<div class="panel panel-primary" id="reg-forms" class="well"  >
  <?php displayMessage(); ?>
<form action="" method="POST">
                

              <h1 class="h3 mb-3 font-weight-normal" style="text-align: center"> Create Account </h1><br>
             <table class="table ">
               <tr>
                  <td style="font-weight: bolder">First Name </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="fname" id="first_name" placeholder="First Name" required autofocus="">
                    </div>
                  </td> 
               </tr>
               <tr>
                  <td style="font-weight: bolder">Last Name </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="lname" id="last_name" placeholder="Last_Name" required autofocus="">
                    </div>
                  </td> 
               </tr>
               <tr>
                 <td style="font-weight: bolder">Phone </td>
                 <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="phone" id="phone" placeholder="Phone Number" 
                      required autofocus="">
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Current Address </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="address" placeholder="address" required autofocus=""><br>
                    <input type="text" class="form-control" name="district" placeholder="district" required autofocus=""><br>
                    <input type="text" class="form-control" name="contry" placeholder="contry" required autofocus=""><br>
                    </div>  
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="city" placeholder="city" required autofocus=""><br>   
                      <input type="text" class="form-control" name="state" placeholder="state" required autofocus=""><br>
                      <input type="text" class="form-control" name="pincode" placeholder="pincode" required autofocus=""><br>
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Gender </td>
                  <td>
                    <div class="col-sm-4">
                      
                               <input type="radio" name="gender" value="Male" style="margin-left: 50px;" checked="true" > Male
                               <input type="radio" name="gender" value="Female" style="margin-left: 50px;"> Female
                    </div>
                  </td>
               </tr>         
               <tr>
                  <td style="font-weight: bolder">Date of Birth </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="date" class="form-control" name="dob" id="dob" required autofocus="">
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Email </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="email" class="form-control" name="email" id="email" placeholder="Email" required autofocus="">
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Password </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="Password" class="form-control" name="pass" id="pass" placeholder="Create Password" required autofocus="">
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Confirm Password </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="Password" class="form-control" name="cpass" id="cpass" placeholder="Confirm Password" required autofocus="">
                    </div>
                  </td>
               </tr>
             </table>
             <hr>
              <button class="btn btn-lg btn-success" name="signup" type="submit">Submit</button>
            


            </form>
</div> </div>  
</body>
</html>




          














           
           
           
           
           
           
