<!DOCTYPE html>
<html lang="en">
<head>
  <title>OnDemandService</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
<style type="text/css">
  #reg-forms button[type="submit"]{
     padding-top: 10px;
     padding-bottom: 10px;
     padding-right: 50px;
     padding-left: 50px;
     align-content: center;
      }
  #reg-forms{
     margin-top: 100px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  #reg-forms form {
    padding: 15px;
    margin: 10;
}
#logreg-forms .form-control {
    position: relative;
    box-sizing: border-box;
    height: auto;
    padding: 10px;
    font-size: 16px;
}
.nav{
      font-size:13px;  padding-left:70px; padding-right:50px; 
    }
  @media screen and (max-width: 768px) {
    .nav {
      padding-right:5px;
    }

</style>
</head>
<body>

<?php include('includes/header.php') ?>

<div class="" style="margin-top: 100px;">
  <div class="col-sm-4"></div>
  <div class="col-sm-3">
<div class="panel panel-primary" style="margin: 10px;">
  <div class="panel-heading">
    <h2>Verify Your Email</h2>
    <p>Verification email has been sent to email  address</p>
    <p> please kindly verify to proceed </p>
    <p> OR </p>
    <a href="log_out.php" style="color: red ">click here to log-out</a>
  </div>
</div>
</div>
</div>

</body>
</html>




          














           
           
           
           
           
           
