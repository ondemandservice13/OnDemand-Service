<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">
  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  .panel{
    background-color: white;
  }
.choose_file{
    position:relative;
    display:inline-block;    
    border-radius:8px;
    border:lightblue solid 1px;
    width:120px; 
    padding: 4px 6px 4px 8px;
    font: normal 14px Myriad Pro, Verdana, Geneva, sans-serif;
    color: #7f7f7f;
    margin-top: 2px;
    background:white;
    cursor: pointer;
}
.choose_file input[type="file"]{
    -webkit-appearance:none; 
    position:absolute;
    top:0; left:0;
    opacity:0; 
     cursor: pointer;
}

  img {
    margin: 10px;
    height: 150px;
    width: 150px;
    border-color: black;
    border-width: 10px;
    border-radius: 8px;
  }
  
.profile-edit-btn{
    border: none;
    border-radius: 1.5rem;
    width: 70%;
    padding: 2%;
    font-weight: 600;
    color: lightblue;
    cursor: pointer;
}
table {
    border-top-style: none;
    border-left-style: none;
    border-right-style: none;
    border-bottom-style: none;
}

#userReview{
border: solid black;
border-radius: 0.5rem;
color:white;
padding: 5px;
font-weight: bold;
}

  .star{
    color:goldenrod;
    font-size: 2.5rem;
    padding: 0.1rem;
  }

  .star::before{
    content:'\2606';
    cursor: pointer;
  }

  .star.rated::before{
    content: '\2605';
  }
</style>
</head>
<body style="">
<?php include('includes/profileheader.php') ?>

<div class="profile-container bootstrap snippet">

    <div class="">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div>
    </div><br>

<div class="" style="margin-left: 5px">    
  <div class="col-sm-1" style=""></div>    
     <div class="col-sm-9" style="">

         <div class="panel panel-primary" >
           <div class="panel-body">
              <div class="row" style="padding-left: 10px">
               <div class="col-sm-2 ">
                  <?php if($user->pimg == null) : ?>
                  <form method="POST" enctype="multipart/form-data">  
                  <?php if($user->gender == 'Male') : ?>  
                  <img class="img"  src="img_avatar.png" alt="avtar">
                  <?php else: ?>
                  <img class="img"  src="img_avatar2.png" alt="avtar">
                <?php endif; ?>
                   <input class="file-upload" name="file" type="file" accept="image/*"/>
                  <br>
                  <input class="choose_file" style="text-align: center ;margin-left: 20px" type="submit" name="upload" value="Upload" />
                
                </form>
                  <?php else: ?>

                <form method="POST" enctype="multipart/form-data">  
                  <img class="img"  src="img/<?php echo $user->pimg ?>" alt="avtar">
                   <input class="file-upload" name="file" type="file" accept="image/*"/>
                  <br>
                  <input class="choose_file" style="text-align: center ;margin-left: 20px" type="submit" name="upload" value="Upload">
                
                </form>

                 <?php endif; ?>
                 
               </div>
               <div class="col-sm-4">

                 <h2 class=" mb-3 font-weight-normal" style="text-align: left;" ><?php echo $user->firstName ?> <?php echo $user->lastName ?></h2>
                 <h3 class="h4 mb-3 font-weight-bold" style="text-align: left; color: #818182;" >Rating : <?php starRating($user_reviews); ?></h3>
                 
                <h3 class="h4 mb-3 font-weight-bold" style="text-align: left; color: #818182;" >
                Review : <?php getSentiment($user_reviews); ?>
                         </h3>

              </div>
              </div>
              <br>
              <div class="row" style="padding-left: 10px">

          <ul class="nav nav-tabs" style="margin-left: 15px">
            <li class="active"><a data-toggle="tab" href="#home">Details</a></li>
            <li><a data-toggle="tab" href="#menu1">About</a></li>
          </ul>
          <br> 
          <div class="tab-content">

            <div id="home" class="tab-pane fade in active">
              
           <form class="form" action="" method="post" id="registrationForm"> 
             
              <?php if(isset($_POST['edit'])) : ?>


             <table class="table" style=" ;margin-left: ; margin-right: 0px ">
               <tr>
                  <td style="font-weight: bolder">First Name </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="fname" id="first_name" value="<?php echo $user->firstName ?>">
                    </div>
                  </td> 
               </tr>
               <tr>
                  <td style="font-weight: bolder">Last Name </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="lname" id="last_name" value="<?php echo $user->lastName ?>">
                    </div>
                  </td> 
               </tr>
               <tr>
                 <td style="font-weight: bolder">Phone </td>
                 <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="mobile" id="mobile" value="<?php echo $user->mobile ?>">
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Email </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="email" id="email" value="<?php echo $user->email ?>">
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Address </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="address" placeholder="address" value="<?php echo $user->address ?>"><br>
                    <input type="text" class="form-control" name="district" placeholder="district" value="<?php echo $user->district ?>"><br>
                    <input type="text" class="form-control" name="contry" placeholder="contry" value="<?php echo $user->contry ?>"><br>
                    </div>  
                    <div class="col-sm-4">
                      <input type="text" class="form-control" name="city" placeholder="city" value="<?php echo $user->city ?>"><br>   
                      <input type="text" class="form-control" name="state" placeholder="state" value="<?php echo $user->state ?>"><br>
                      <input type="text" class="form-control" name="pincode" placeholder="pincode" value="<?php echo $user->pincode ?>"><br>
                    </div>
                  </td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Gender </td>
                  <td>
                    <div class="col-sm-4">
                      <?php if($user->gender == 'Male') : ?>
                               <input type="radio" name="gender" value="Male" style="margin-left: 50px;" checked="checked" > Male
                               <input type="radio" name="gender" value="Female" style="margin-left: 50px;"> Female
                               <?php else : ?>
                               <input type="radio" name="gender" value="Male" style="margin-left: 50px;"> Male
                               <input type="radio" name="gender" value="Female" style="margin-left: 50px;" checked="checked"> Female
                      <?php endif; ?>
                    </div>
                  </td>
               </tr>         
               <tr>
                  <td style="font-weight: bolder">Date of Birth </td>
                  <td>
                    <div class="col-sm-4">
                      <input type="date" class="form-control" name="dob" id="dob" value="<?php echo $user->dob ?>">
                    </div>
                  </td>
               </tr>
             </table>

             <div class="col-sm-2">
             <button class="btn btn-lg btn-success" name="save" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Save</button>
             </div>

             <?php else : ?>
               
             <table class="table " style="width: 80%; margin-left: 30px ">

               <tr>
                  <td style="font-weight: bolder">Name </td>
                  <td style="font-weight: lighter; color: blue"><?php echo $user->firstName ?> <?php echo $user->lastName ?></td> 
               </tr>
               <tr>
                 <td style="font-weight: bolder">Phone </td>
                  <td style="font-weight: lighter; color: blue"> <?php echo $user->mobile ?></td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Email </td>
                  <td style="font-weight: lighter; color: blue"> <?php echo $user->email ?></td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Address </td>
                  <?php $addr = $user->address.','.$user->city.',<br>'.$user->district.','.$user->state.','.$user->contry.','.$user->pincode;?>
                  <td style="font-weight: lighter; color: blue"> <?php echo $addr ?></td>
               </tr>
               <tr>
                  <td style="font-weight: bolder">Gender </td>
                  <td style="font-weight: lighter; color: blue"> <?php echo $user->gender ?></td>
               </tr>         
               <tr>
                  <td style="font-weight: bolder">Date of Birth </td>
                  <td style="font-weight: lighter; color: blue"> <?php echo $user->dob ?></td>
               </tr>
             </table>
             
             <div class="col-sm-2" > 
               <button class="btn btn-lg btn-primary" name="edit" type="submit" style="">Edit</button>
              </div>
             <?php endif ?> 
            </form> 
          </div>

            <div id="menu1" class="tab-pane fade">
              <table class="table" style="width: 400px; margin-left: 30px">
                <tr>
                  <td style="font-weight: bolder">Total Post </td>
                  <td style="font-weight: lighter; color: blue"><?php echo $total_posts->total?></td>
                </tr>
                <tr>
                  <td style="font-weight: bolder">Created Post </td>
                  <td style="font-weight: lighter; color: blue"><?php echo $created_posts->total?></td>
                </tr>
                <tr>
                  <td style="font-weight: bolder">Applied Post </td>
                  <td style="font-weight: lighter; color: blue"><?php echo $applied_posts->total?></td>
                </tr>
                <tr>
                  <td style="font-weight: bolder">Active Post </td>
                  <td style="font-weight: lighter; color: blue"><?php echo $active_posts->total?></td>
                </tr>
                <tr>
                  <td style="font-weight: bolder">Compelete Post </td>
                  <td style="font-weight: lighter; color: blue"><?php echo $completed_posts->total?></td>
                </tr>
              </table>
            </div>

          </div>

              </div> 

           </div>
         </div>     
     </div>
  </div> 
</div>                                        


<script type="text/javascript">
  $(document).ready(function() {

    
    var readURL = function(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('.img').attr('src', e.target.result);
            }
    
            reader.readAsDataURL(input.files[0]);
        }
    }
    

    $(".file-upload").on('change', function(){
        readURL(this);
    });

    
});

$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();   
});

</script>  

</body></html>                                          