<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  .panel{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }

  .nav-pills{
    font-size:20px;
    font-weight: lighter;
  }
   @media screen and (max-width: 768px) {
    .nav-pills {
        font-size:15px;
        font-weight: lighter;
    }
</style>

</head>
<body>
<?php include('includes/profile_hrader.php') ?>


<div id="main">
<div class="profile-container bootstrap snippet">
    <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      <div class="col-sm-1"></div>
    </div>


    <div class="row" style="margin-left: 5px">
      <div class="col-sm-1"><!--left col-->
                   
          </div><!--right col-->
          <div class="col-sm-9">
            
<ul class="nav nav-pills" id="nav-pills" style="">
  <li class="nav-item">
    <a class="nav-link" href="userposts.php?category=all">All Posts</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="userposts.php?category=user_posts">Created</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="userposts.php?category=applied_posts">Applied</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="userposts.php?category=completed_posts">Completed</a>
  </li>
</ul>
<hr>
                  <form class="form" action="" method="post" id="">
                      <div class="form-group">
                          <div class="container">
                            <div class="row">
                              <?php if($user_posts) : ?>
                                
                                <?php foreach ($user_posts as $post) : ?>
                                   
                                <div class="col-sm-4">
                                  <div class="panel panel-primary">
                                  <?php if($post->completion_date!=null) :?>
                                    <div class="panel-heading" style= "background-color: lightgreen;"><?php echo $post->p_title; ?></div>
                                  <?php elseif($post->applyby!=null) : ?>   
                                  <div class="panel-heading"><?php echo $post->p_title; ?></div>
                                  <?php else: ?>
                                   <div class="panel-heading" style= "background-color: black;"><?php echo $post->p_title; ?></div> 
                                  <?php endif; ?>                                         
                                         <div class="panel-body">
                                              <label name="d">Discription:<?php echo $post->p_id; ?> </label><br>
                                              <label>Discription:<?php echo $post->p_desc; ?> </label><br>
                                              <label>location: <?php echo $post->loc; ?> </label><br>
                                              <label>Price: <?php echo $post->stipend; ?> </label><br>
                                          </div>

                                      <div class="panel-footer">
                                        <?php if($post->provider == getUser()['user_id']): ?>
                                        <a href="dbhelper.php?id=<?php echo $post->p_id;?>&u_id=<?php echo $post->applyby; ?>&a=u">More Details</a>
                                        <?php else : ?>
                                        <a href="findpostdetails.php?id=<?php echo $post->p_id;?>&u_id=0 ">More Details</a>
                                      <?php endif; ?>
                                      </div>  
                                     </div>
                                    </div>
                                 <?php endforeach; ?>                                                       
                               <?php else : ?>
                               <h2><i>No Post By <?php echo $user->firstName ?></i></h2>                               
                               <h4><i><a href='createpost.php'>click here to create job post</a></i></h4>                       
                              <h4><i><a href='findposts.php'>click here to find job</a></i></h4>   
                              <?php endif; ?>  
                            </div>
                       </div><br>
                       </div>
                  </form>
                 
              </div>
            </div>
          </div>
              

          </div> 

                                      
   </body></html>                                          