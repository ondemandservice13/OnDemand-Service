 <!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">
  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  .panel{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }


  .star{
    color:goldenrod;
    font-size: 4.0rem;
    padding: 0 1rem;
  }

  .star::before{
    content:'\2606';
    cursor: pointer;
  }

  .star.rated::before{
    content: '\2605';
  }
</style>

</head>
<body>

<?php include('includes/findpostheader.php') ?>

<div id="main"> 
<div class="profile-container bootstrap snippet">
    <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      <div class="col-sm-1"></div>
    </div>


    <div class="row" style="margin-left: 5px">
      <div class="col-sm-1"><!--left col-->
                                 
          </div><!--right col-->
          <div class="col-sm-10">
           <hr>
                  <form class="form" action="" method="POST">
                          
                         
                          <?php
                             /*
                              *     ******************** POST DETAILS *************************************************
                              */
                            ?>
                            
                            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Job Post Details</h1> 
                               </div>
                               <div class="panel-body">
                                <div class="row">
                                    <div class="col-xs-4">
                                    <label >Post Title:<p style="font-weight: lighter;"><?php echo $post->p_title; ?></p></label>
                                    </div>
                                    <div class="col-xs-4">                       
                                    <label>Post Discrption:<p style="font-weight: lighter;"><?php echo $post->p_desc; ?></p></label><br>
                                    </div>
                                </div>
                                <div class="row"> 
                                    <div class="col-xs-4">   
                                    <label>Location :<p style="font-weight: lighter;"><?php echo $post->loc; ?></p></label>
                                    </div>
                                    <div class="col-xs-4">
                                    <label>Stipend :<p style="font-weight: lighter;"><?php echo $post->stipend; ?></p></label><br>
                                    </div>
                                </div>
                                <div class="row">
                                  <?php if($postacceptance == null) : ?>
                                    <?php if($postidcheck == Null ) : ?>
                                    <div class="col-xs-6">   
                                    <button class="btn btn-success" type="submit" name = "apply" >Apply</button>
                                    </div>
                                    <?php elseif($postidcheck != Null ) : ?>
                                    <div class="col-xs-6">   
                                    <button class="btn btn-success" type="submit" name = "apply" disabled="">Applied</button>
                                    </div>                                    
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <div class="container">   
                                    <button class="btn btn-danger" type="submit" name = "apply" disabled="">Accepted</button>
                                    <?php if($postcompletion == null and $poststart == null) : ?> 
                                    <button class="btn btn-info"style ="padding-left: 20px; padding-right: 20px;" type="submit" name = "start">Start</button>
                                    <?php elseif($poststart != null and $postcompletion== null): ?>
                                    <button class="btn btn-info"style ="padding-left: 20px; padding-right: 20px;" type="submit" name = "apply" disabled="">Started</button>
                                    <?php else : ?>
                                    <button class="btn btn-success"style ="padding-left: 20px; padding-right: 20px;" type="submit" disabled="">Completed</button>
                                  <?php endif; ?>
                                    </div>  
                                  <?php endif; ?>                                     
                                </div>
                                </div>     
                                </div>
                <?php
                /*
                 *     ******************** POST Feedback *************************************************
                 */
                 ?>

                            <?php if($postcompletion !=  null and $checkSeekerFeed == null): ?>
                                <div class="panel panel-primary">
                                  <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Rate Provider</h1>                           
                                  </div>
                                  <div class="panel-body">                                      
                                      <div class="stars" data-rating="0" style="margin-left: 50px">                                        
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                      </div>
                                      <div class="col-xs-5">
                                      <form method="post">
                                        <input type="text" class="form-control" id="rate" name="rate" value="Rating : 0/5" disabled="" 
                                        style="text-align: center;" /><br>
                                        <input type="text" class="rate" name="rateno" style="display: none" value="" />   
                                        <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
                                        <button class="btn btn-md btn-success" style ="padding-left: 20px; padding-right: 20px;" type="submit" name="feedback_posts"></i>Post</button>
                                      </form>  
                                      </div>                                
                                  </div>  
                                </div>  
                              <?php endif; ?>
                <?php
                /*
                 *     ******************** POST CREATOR *************************************************
                 */
                 ?>
                            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Job Provider</h1> 
                               </div>
                               <div class="panel-body">
                            <div class="row">
                            <div class="col-xs-4">   
                                <label>Name :<p style="font-weight: lighter;"><?php echo $post->firstName.' '.$post->lastName; ?></p></label>
                            </div>
                            <div class="col-xs-4">
                                <label>Contact :<p style="font-weight: lighter;"><?php echo $post->mobile; ?></p></label>
                            </div>
                            </div>
                            <div class="row">
                            <div class="col-xs-4">
                  <?php $addr = $post->address.','.$post->city.','.$post->district.','.$post->state.','.$post->contry.','.$post->pincode;?>
                               <label>Address :<p style="font-weight: lighter;"><?php echo $addr; ?></p></label>
                            </div>
                            <div class="col-xs-4">
                                <label>Email :<p style="font-weight: lighter;"><?php echo $post->email; ?></p></label>
                            </div>
                            </div>                            
                            </div>     
                            </div>


            <?php
                /*
                 *     ******************** POST STATUS *************************************************
                 */
                 ?>
                            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Job Status</h1> 
                               </div>
                               <div class="panel-body">
                                <?php if($poststatus != null) :?>
                            <div class="row">
                            <div class="col-sm-4">   
                                <label>Applied On:<p style="font-weight: lighter;"><?php echo $poststatus->apply_date ?></p></label>
                            </div>
                            <div class="col-sm-4">
                                <label>Accepted On:<p style="font-weight: lighter;"><?php
                               
                                if($poststatus->apply_date ==null){
                                  echo "";
                                }else if($poststatus->accept_date !=null){
                                  echo $poststatus->accept_date;
                                }else{
                                  echo "waiting for accept...";
                                }
                                ?></p></label>
                            </div>
                            <div class="col-sm-4">   
                                <label>Complited On:<p style="font-weight: lighter;"><?php 
                                if($poststatus->accept_date ==null){
                                  echo "";
                                }else if($poststatus->completion_date !=null){
                                  echo $poststatus->completion_date;
                                }else{
                                  echo "On the way..";
                                }
                                ?></p></label>
                            </div>
                            <div class="col-xs-4">
                                <label><p style="font-weight: lighter;"><?php echo "" ?></p></label>
                            </div>
                            </div>
                            <?php endif; ?>                            
                            </div>     
                            </div>
                                
                      </form>
              </div>
            </div>
          </div>
              

          </div>
        <script type="text/javascript">
          document.addEventListener('DOMContentLoaded', function(){

            let stars = document.querySelectorAll('.star');
            stars.forEach(function(star){
            star.addEventListener('click', setRating);
          });

            let rating = parseInt(document.querySelector('.stars').getAttribute('data-rating'));
            let target = stars[rating - 1];
            target.dispatchEvent(new MouseEvent('click'));
          });

          function setRating(ev){
            let span = ev.currentTarget;
            let stars =document.querySelectorAll('.star');
            let match = false;
            let num = 0;
            stars.forEach(function(star , index){
              if(match){
                star.classList.remove('rated');
              }else{
                star.classList.add('rated');
              }
              if(star === span){
                match = true;
                num = index + 1;
              }
            });
            document.querySelector('.stars').setAttribute('data-rating',num);            
            document.querySelector('#rate').setAttribute('value',"Rating : "+num+"/5");            
            document.querySelector('.rate').setAttribute('value',num);            
          }

        </script>                                     
   </body></html>                                          