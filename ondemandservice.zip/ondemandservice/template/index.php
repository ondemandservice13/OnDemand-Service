<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Theme Made By www.w3schools.com -->
  <title>On-Demand Service</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
   <link rel="stylesheet" href="css/form1.css">
   <link rel="stylesheet" href="css/indexheader.css">
  <style>
    .nav{
      font-size:13px;  padding-left:70px; padding-right:20px; 
    }
    
  @media screen and (max-width: 768px) {
    .nav {
      padding-right:5px;
    }

  </style>
</head>
<body id="myPage" data-spy="scroll" data-target=".navbar" data-offset="60">
<?php include('includes/header.php') ?>

<div class="jumbotron text-center">
  <h1>ON-DEMAND SERVICE</h1> 
  <p>Get help in daily work </p> 
 </div>

<!-- Container (About Section) -->
<div id="about" class="container-fluid">
  <div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-8">
      <h2>About Our Services</h2><br>
      <p>On-Demand Service is platform to provide or find small task of our daily work. In our daily life there are lots of work we need to do on regular basis like grossary shoping, delivery, moving, shifting heavy furniture,gardening. But some people are not able to do such work because of their busy work schedule, lack of man power so such work can be done by people near by your area who need some quick cash by doing your small task.</p>
      <p>On-Demand Service provide efficient way to Provide or find small task for you here you can post what type of task you needs to perform and you can get numbers of people who can help you for exchange of quick cash. Also you can find task to perfom in your free time. </p>
      <br><a href="login.php" class="btn btn-default btn-lg">Let's Start</a>
    </div>
  </div>
</div>

<!-- Container (Services Section) -->
<div id="services" class="container-fluid text-center bg-grey">
  <h2>How It Works</h2>
    <div class="row slideanim">
    <div class="col-sm-6" style="border-right: 2px solid white;">
      <hr style="border-color: black">
      <span class="glyphicon glyphicon-user logo-small"></span>
      <h4>Be Provider</h4>
    <div class="row">  
      <div class="col-sm-6">
      <span class=" glyphicon glyphicon-list-alt logo-small"></span>
      <h4>Create Post</h4>
      <p>Create task post ...</p>
      </div>
      <div class="col-sm-6">
      <span class="glyphicon glyphicon-time logo-small"></span>
      <h4>Wait for Seekers</h4>
      <p>wait for seeker to apply ...</p>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
      <span class=" glyphicon glyphicon-ok logo-small"></span>
      <h4>Confirm Seeker</h4>
      <p>Comfirm seeker who best for task ...</p>
    </div>
    <div class="col-sm-6">
      <span class=" glyphicon glyphicon-piggy-bank logo-small"></span>
      <h4>Payment</h4>
      <p>Pay seeker for his work.</p>
    </div>
  </div>
    </div>
    <div class="col-sm-6" style="border-left: 2px solid white;">
      <hr style="border-color: black">
      <span class=" glyphicon glyphicon-user logo-small"></span>
      <h4>Be Seeker</h4>
  <div class="row">
      <div class="col-sm-6">
      <span class=" glyphicon glyphicon-search logo-small"></span>
      <h4>Find Task</h4>
      <p>Find task and apply ...</p>
    </div>
    <div class="col-sm-6">
      <span class="glyphicon glyphicon-time logo-small"></span>
      <h4>Wait to confirm</h4>
      <p>Wait to confirmation from provider ...</p>
    </div>
  </div>
  <div class="row">
    <div class="col-sm-6">
      <span class=" glyphicon glyphicon-thumbs-up logo-small"></span>
      <h4>Perform Task</h4>
      <p>After confirm perfom task ...</p>
    </div>
    <div class="col-sm-6">
      <span class="glyphicon glyphicon-piggy-bank logo-small"></span>
      <h4>Payment</h4>
      <p>Recevie Payment.</p>
    </div>
  </div>
    </div>
  </div>
    
</div>

<!-- Container (Pricing Section) -->
<div id="pricing" class="container-fluid">
  <div class="text-center">
    <h2>Type of task</h2>
    <h4>Some examples of taks you can post/search.</h4>
  </div>
   <br><br> 
  <div class="row slideanim text-center">
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-shopping-cart logo-small"></span>
      <h4>Grossary Shoping</h4>
      <p>Helped to deliver some grossary product...</p>
    </div>
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-cutlery logo-small"></span>
      <h4>Cooking</h4>
      <p>Help in cooking something ...</p>
    </div>
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-map-marker logo-small"></span>
      <h4>Pick Up</h4>
      <p>Hepl to pick up or drop someone ...</p>
    </div>
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-tree-deciduous logo-small"></span>
      <h4>Gardning</h4>
      <p>taking care of trees or gardan ...</p>
    </div>
  </div>
  <br><br><br>
    <div class="row slideanim text-center">
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-random logo-small"></span>
      <h4>Moving/Shifting</h4>
      <p>Help in moving or shifting furniture ...</p>
    </div>
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-baby-formula logo-small"></span>
      <h4>Baby sitting</h4>
      <p>Taking care of baby for someone ...</p>
    </div>
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-scissors logo-small"></span>
      <h4>Party Decoration</h4>
      <p>Hepl in birthday party decoration ...</p>
    </div>
    <div class="col-sm-3">
      <span class="glyphicon glyphicon-question-sign logo-small"></span>
      <h4>Any Task</h4>
      <p>You can post any task that you want to perform ...</p>
    </div>
  </div>
</div>

<!-- Container (Contact Section) -->
<div id="contact" class="container-fluid bg-grey">
  <br><br>
  <h2 class="text-center">CONTACT</h2>
  <br><br>
  <div class="row">
    <div class="col-sm-5">
      <p>Contact us and we'll get back to you within 24 hours.</p>
      <p><span class="glyphicon glyphicon-envelope"></span> ondemandservice13@gmail.com</p>
    </div>
    <div class="col-sm-7 slideanim">
      <form method="POST" action="index.php">
      <div class="row">
        <div class="col-sm-6 form-group">
          <input class="form-control" id="name" name="Customer_name" placeholder="Name" type="text" required>
        </div>
        <div class="col-sm-6 form-group">
          <input class="form-control" id="email" name="Customer_email" placeholder="Email" type="email" required>
        </div>
      </div>
      <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
      <div class="row">
        <div class="col-sm-12 form-group">
          <button class="btn btn-default pull-right" name="enquiry" type="submit">Send</button>
        </div>
      </div>
      </form>
    </div>
  </div>
</div>

<!-- Image of location/map -->
<footer class="container-fluid text-center">
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-chevron-up"></span>
  </a>
</footer>

<script>



$(document).ready(function(){
  // Add smooth scrolling to all links in navbar + footer link
  $(".navbar a, footer a[href='#myPage']").on('click', function(event) {
    // Make sure this.hash has a value before overriding default behavior
    if (this.hash !== "") {
      // Prevent default anchor click behavior
      event.preventDefault();

      // Store hash
      var hash = this.hash;

      // Using jQuery's animate() method to add smooth page scroll
      // The optional number (900) specifies the number of milliseconds it takes to scroll to the specified area
      $('html, body').animate({
        scrollTop: $(hash).offset().top
      }, 900, function(){
   
        // Add hash (#) to URL when done scrolling (default click behavior)
        window.location.hash = hash;
      });
    } // End if
  });
  
  $(window).scroll(function() {
    $(".slideanim").each(function(){
      var pos = $(this).offset().top;

      var winTop = $(window).scrollTop();
        if (pos < winTop + 600) {
          $(this).addClass("slide");
        }
    });
  });
})

</script>

</body>
</html>
