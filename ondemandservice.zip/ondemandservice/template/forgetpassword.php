<!DOCTYPE html>
<html lang="en">
<head>
  <title>OnDemandService</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
<style type="text/css">
  #reg-forms button[type="submit"]{
     padding-top: 10px;
     padding-bottom: 10px;
     padding-right: 50px;
     padding-left: 50px;
     align-content: center;
      }
  #reg-forms{
     margin-top: 100px;
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  #reg-forms form {
    padding: 15px;
    margin: 10;
}
#logreg-forms .form-control {
    position: relative;
    box-sizing: border-box;
    height: auto;
    padding: 10px;
    font-size: 16px;
}

</style>
</head>
<body>

<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="index.php">On-Demand Service</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">

        <li><a href="login.php">Log-In</a></li>
        <li><a href="sign_up.php">Sign-Up</a></li>
        <li><a href="index.php#about">About</a></li>
        <li><a href="index.php#services">Services</a></li>
        <li><a href="index.php#pricing">Task</a></li>
      </ul>
  </div>
</div>
</nav>

<br><br>
<div class="">
  <div class="col-sm-4"></div>
  <div class="col-sm-4">
     <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      <div class="col-sm-1"></div>
    </div>
    
<div class="panel panel-primary" style="margin: 40px;">

 <?php if(isset($_POST['forgetpass'])) :?>

  <div class="panel-heading">
    <h2>Verify Your Email</h2>
    <p>Verification email has been sent to email  address</p>
    <p> please kindly verify to reset your password </p>
  </div>

    <?php else : ?> 

  <div class="panel-heading">
   <h3 class="font-weight-normal" style="text-align: center;" >Password Recovery</h3>
 </div>
  <div class="panel-body"> 
   <form method="post">
    <input type="email" id="email" name="email" class="form-control" placeholder="Your registered email address" required autofocus="">
    <br>
    <button class="btn btn-primary" name="forgetpass" >Send</button> 
   </form>
   </div> 
      <?php endif; ?>
  </div>
</div>
</div>
</div>

</body>
</html>