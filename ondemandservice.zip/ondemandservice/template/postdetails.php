<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  .panel{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
  .star{
    color:goldenrod;
    font-size: 4.0rem;
    padding: 0 1rem;
  }

  .star::before{
    content:'\2606';
    cursor: pointer;
  }

  .star.rated::before{
    content: '\2605';
  }
</style>

</head>
<body>

<?php include('includes/userpostsheader.php') ?>

<div id="main">
<div class="profile-container bootstrap snippet">

 <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      
    </div>

    <div class="row">
          
          <div class="col-sm-1">          
          </div><!--right col-->
          <div class="col-sm-10">
           <hr>
                 
                <?php
                /*
                 *     ******************** POST STATUS *************************************************
                 */
                 ?>
                            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Job Status</h1> 
                               </div>
                               <div class="panel-body">
                        <?php if($poststatus != null) : ?>
                           <table class="table table-striped">
                                <thead>
                                  <tr>
                                    <th>Applied By</th>
                                    <th>Applied On</th>
                                    <th>Completed On</th>
                                    <th>Action</th>

                                  </tr>
                                </thead>
                             <?php foreach ($poststatus as $poststatus) :?>
                             <?php if($poststatus->accept_date == null) : ?>    
                                <tbody>
                                  <tr>
                                    <td><a href="dbhelper.php?u_id=<?php echo $poststatus->u_id?>&a=u"><?php echo $poststatus->firstName." ".$poststatus->lastName;  ?></a></td>
                                    <td><?php echo $poststatus->apply_date?></td>                                    
                                    <td>----/--/--</td>
                                    <td><a href="dbhelper.php?u_id=<?php echo $poststatus->u_id?>&p_id=<?php echo $poststatus->p_id?>&a=c">Confirm</a></td>
                                  </tr>
                                </tbody>
                            <?php else : ?>
                              <tbody>
                                  <tr>
                                    <td><a href="postdetails.php?u_id=<?php echo $poststatus->u_id?>"><?php echo $poststatus->firstName." ".$poststatus->lastName;  ?></a></td>
                                    <td><?php echo $poststatus->apply_date?></td>
                                    
                                    <?php if($poststart == null) : ?>
                                    <td>----/--/--</td>  
                                    <td>Confirmed</td>
                                    <?php elseif($postcompletion == null): ?>
                                    <td>----/--/--</td>                                      
                                    <td><a href="dbhelper.php?u_id=<?php echo $poststatus->u_id?>&p_id=<?php echo $poststatus->p_id?>&a=d">Done</a></td>
                                    <?php else : ?>                                      
                                    <td><?php echo $poststatus->completion_date?></td>   
                                    <td>Completed</td>
                                    <?php endif; ?>
                                  </tr>  
                                </tbody>                                                     
                            <?php endif; ?>
                            <?php endforeach; ?>
                          </table>
                        <?php else: ?>
                            <div>
                              <label><p style="font-weight: lighter;">Waiting for Seeker...</p></label>
                            </div> 
                        <?php endif; ?>                               
                            </div>     
                            </div>

              <?php
                /*
                 *     ******************** POST Feedback *************************************************
                 */
                 ?>

                            <?php if($postcompletion !=  null and $checkproviderFeed == null): ?>
                                <div class="panel panel-primary">
                                  <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Rate Provider</h1>                           
                                  </div>
                                  <div class="panel-body">                                      
                                      <div class="stars" data-rating="0" style="margin-left: 50px">                                        
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                        <span class="star" >&nbsp;</span>
                                      </div>
                                      <div class="col-sm-5">
                                      <form method="post">
                                        <input type="text" class="form-control" id="rate" name="rate" value="Rating : 0/5" disabled="" 
                                        style="text-align: center;" /><br>
                                        <input type="text" class="rate" name="rateno" style="display: none" value="" />   
                                        <textarea class="form-control" id="comments" name="comments" placeholder="Comment" rows="5"></textarea><br>
                                        <button class="btn btn-md btn-success" style ="padding-left: 20px; padding-right: 20px;" type="submit" name="feedback_posts">Post</button>
                                      </form>  
                                      </div>                                
                                  </div>  
                                </div>  
                              <?php endif; ?>

                           <?php  /*
                 *     ******************** POST CREATOR *************************************************
                 */
                 ?>
                            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Job Seeker</h1> 
                               </div>
                               <div class="panel-body">  
                            <?php if($seeker !=  null) :?>
                            <div class="row">
                            <div class="col-xs-4">   
                                <label>Name :<p style="font-weight: lighter;"><?php echo $seeker->firstName.' '.$seeker->lastName; ?></p></label>
                            </div>
                            <div class="col-xs-4">
                                <label>Contact :<p style="font-weight: lighter;"><?php echo $seeker->mobile; ?></p></label>
                            </div>
                            <div class="col-xs-4">   
                            </div>
                            </div>
                            <div class="row">
                            <div class="col-xs-4">
        <?php $addr = $seeker->address.','.$seeker->city.','.$seeker->district.','.$seeker->state.','.$seeker->contry.','.$seeker->pincode;?>
                                <label>Address :<p style="font-weight: lighter;"><?php echo $addr; ?></p></label>
                            </div>
                            <div class="col-xs-4">
                                <label name="email">Email :<p style="font-weight: lighter;"><?php echo $seeker->email; ?></p></label>
                            </div>
                            <div class="col-xs-4">
                            </div>
                            </div>
                            <?php endif; ?>  
                                                 
                            </div>     
                            </div>
                                                      
                          <?php
                             /*
                              *     ******************** POST DETAILS *************************************************
                              */
                            ?>
                            
                            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Job Post Details
                               </h1> 
                               </div>
                               <div class="panel-body">
                                <div class="row">
                                    <div class="col-xs-4">
                                    <label >Post Title:<p style="font-weight: lighter;"><?php echo $post->p_title; ?></p></label>
                                    </div>
                                    <div class="col-xs-4">                       
                                    <label>Post Discrption:<p style="font-weight: lighter;"><?php echo $post->p_desc; ?></p></label><br>
                                    </div>
                                </div>
                                <div class="row"> 
                                    <div class="col-xs-4">   
                                    <label>Location :<p style="font-weight: lighter;"><?php echo $post->loc; ?></p></label>
                                    </div>
                                    <div class="col-xs-4">
                                    <label>Stipend :<p style="font-weight: lighter;"><?php echo $post->stipend; ?></p></label><br>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-4">   
                                    <label>Created On :<p style="font-weight: lighter;"><?php echo $post->c_date; ?></p></label>
                                    </div>
                                    
                                </div>
                                </div>     
                                </div>
              
                                
                      
              </div>
            </div>
          </div>
          </div>
               <script type="text/javascript">
          document.addEventListener('DOMContentLoaded', function(){

            let stars = document.querySelectorAll('.star');
            stars.forEach(function(star){
            star.addEventListener('click', setRating);
          });

            let rating = parseInt(document.querySelector('.stars').getAttribute('data-rating'));
            let target = stars[rating - 1];
            target.dispatchEvent(new MouseEvent('click'));
          });

          function setRating(ev){
            let span = ev.currentTarget;
            let stars =document.querySelectorAll('.star');
            let match = false;
            let num = 0;
            stars.forEach(function(star , index){
              if(match){
                star.classList.remove('rated');
              }else{
                star.classList.add('rated');
              }
              if(star === span){
                match = true;
                num = index + 1;
              }
            });
            document.querySelector('.stars').setAttribute('data-rating',num);            
            document.querySelector('#rate').setAttribute('value',"Rating : "+num+"/5");            
            document.querySelector('.rate').setAttribute('value',num);            
          }

        </script>                                       
   </body></html>                                          