<!DOCTYPE html>
<html lang="en">
<head>
  <title>User Porfile</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src='https://kit.fontawesome.com/a076d05399.js'></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/header1.css">
  <link rel="stylesheet" href="css/form1.css">
  
  <link rel="stylesheet" href="css/sidebar.css">
<style type="text/css">
  .panel{
    box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  }
</style>
</head>
<body>
<?php include('includes/createpostheader.php') ?>




<div id="main">
<div class="profile-container bootstrap snippet">
    <div class="row">
      <div class="col-sm-12 text-center"><?php displayMessage(); ?></div><br>
      <div class="col-sm-1"></div>
    </div>


    <div class="row" style="margin-left: 5px">
      <div class="col-sm-1"><!--left col-->

          </div><!--right col-->
          <div class="col-sm-9">
            <hr>
            <div class="panel panel-primary">
                               <div class="panel-heading">
                               <h1 class="h3 mb-3 font-weight-normal" style="text-align: left;" >Create New Post</h1> 
                               </div>
                               <div class="panel-body">
            <form class="form" action="" method="POST" id="postForm">
                      <div class="form-group">
                          
                          <div class="col-xs-9">
                              <label for="title"><h4>Post Title</h4></label>
                              <input type="text" class="form-control" name="post_title" id="post_title" placeholder="Enter title of post" title="enter your first name if any.">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-9">
                            <label for="last_name"><h4>Post Discription</h4></label>
                              <textarea rows="5" class="form-control" name="post_disp" id="post_disp" placeholder="Enter details of post"></textarea>
                          </div>
                      </div>
                                        
                      <div class="form-group">
                          
                          <div class="col-xs-9">
                              <label for="location"><h4>Job Location</h4></label>
                              <input type="text" class="form-control" id="location" name="location" placeholder="Enter location of job " title="enter a location">
                          </div>
                      </div>
                      <div class="form-group">
                          
                          <div class="col-xs-9">
                              <label for="Stipend"><h4>Stipend</h4></label>
                              <input type="text" class="form-control" name="stipend" id="stipend" placeholder="Enter amount to be paid for job " title="enter a location">
                          </div>
                      </div>
                     
                      <div class="form-group">
                           <div class="col-xs-12">
                                <br>
                                <button class="btn btn-lg btn-success" type="submit" name="create_posts"><i class="glyphicon glyphicon-ok-sign"></i> Post</button>
                            </div>
                      </div>
                </form>
                 
              </div>
            </div>
          </div>
              

          </div>
        </div><!--/col-3-->
    </div>                                         

   </body></html>                                          