<?php require('core/init.php') ?>


<?php
$user = new User();


if(isset($_POST['reset'])){
 $pass = md5($_POST['password']);
 $cpass = md5($_POST['c_password']);
 $u_id = $_GET['u_id'];
 if($pass == $cpass){

 	if($user->updatePassword($pass,$u_id)){
 		$user->deleteOtp($u_id);
 		redirect('index.php#about','password is reset','success');

 	}else{
 		redirect('resetpassword.php','password not update','error');
 	}

 }else{
  redirect('resetpassword.php','password not match','error');
 }
}
$template = new Template('template/resetpassword.php');

echo $template;

?>