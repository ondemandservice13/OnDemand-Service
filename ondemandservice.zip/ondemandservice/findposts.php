<?php require('core/init.php') ?>

<?php
if(isLoggedIn()){
$user = new User();
$user_posts = new Post();
$_SESSION['id']= null;
$template = new Template('template/findposts.php');

$user_id = getUser()['user_id'];
$template->allposts = $user_posts->allfindPosts($user_id);
$template->user = $user->getUserInfo($user_id);


echo $template;
 }else{
      redirect('index.php','','');  
}
?>