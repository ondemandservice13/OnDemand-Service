<?php require('core/init.php') ?>

<?php
if(isLoggedIn()){
	
$user = new User();
$user_posts = new Post();
$template = new Template('template/userposts.php');

$_SESSION['id']= null;
$user_id = getUser()['user_id'];

if($_GET['category']=='all'){

$template->user_posts = $user_posts->getAllPosts($user_id);
}elseif($_GET["category"]=='user_posts'){

$template->user_posts = $user_posts->getAllUserPosts($user_id);
}
elseif($_GET["category"]=='applied_posts'){

$template->user_posts = $user_posts->getAllAppliedPosts($user_id);
}
elseif($_GET["category"]=='completed_posts'){

$template->user_posts = $user_posts->getAllCompletedPosts($user_id);


}

$template->user = $user->getUserInfo($user_id);
echo $template;
}else{
      redirect('index.php','','');  
}
?>