<?php require('core/init.php') ?>

<?php
use Sentiment\Analyzer;
use src\Sentiment\Procedures\SentiText;


function getSentiment($user_reviews){
  $analyzer = new Analyzer();
  $neg = 0;
  $pos = 0;
  $neu = 0;
  foreach ($user_reviews as $review) {
    $output_text = $analyzer->getSentiment($review->comments);
    if($output_text['neg']>=0.5){
      $neg = $neg + 1;
    }elseif ($output_text['pos']>=0.5) {
      $pos = $pos + 1;
    }elseif ($output_text['neu']>=0.5){
      $neu = $neu + 1;
    }
  }
  if($pos>=$neg and $pos>=$neu){
    echo '<button id="userReview" data-toggle="tooltip" data-placement="top" title="Your the Best" style="background-color: green;">Best Tasker</button>';
  }elseif ($neg>=$pos and $neg>=$neu){
    echo '<button id="userReview" data-toggle="tooltip" data-placement="top" title="Be polite! Work hard" style="background-color: red;">Good Tasker</button>';
  }else{
    echo 'Nice';
  }
 }

 function starRating($user_reviews){
  $rating = 0 ;
  $count = 0 ;
  $userRating = 0;
  foreach ($user_reviews as $review) {
    $rating = $rating + $review->rating;
    $count = $count + 1;
  }
  if($rating != 0){
  $userRating = round($rating/$count);
  }
  for($i =1; $i<=5; $i++ ){
    if($userRating!=0){
    echo '<span class="star rated" >&nbsp;</span>';
    $userRating = $userRating - 1;
  }else{
    echo '<span class="star" >&nbsp;</span>';
  }
}
  }
  
if(isLoggedIn()){


$user = new User();
$user_posts = new Post();
$feedback = new Feedback();
if(isset($_POST['upload'])){
  
  $user_id = getUser()['user_id'];
  $name = $_FILES['file']['name'];
  $temp_name = $_FILES['file']['tmp_name'];

  move_uploaded_file($temp_name,"img/".$name);

  if($user->imgUpload($name,$user_id)){

      redirect('profile.php','Profile photo is Upadted ','success');
  }else{

      redirect('profile.php','Profile is Upadted ','success');
  }
  
 }

if (isset($_POST['save'])) {
     $data = array();

    $data['fname'] = $_POST['fname'];
    $data['lname'] = $_POST['lname'];
    $data['mobile'] = $_POST['mobile'];  
    $data['contry'] = $_POST['contry'];
    $data['state'] = $_POST['state'];    
    $data['district'] = $_POST['district'];
    $data['city'] = $_POST['city'];
    $data['address'] = $_POST['address'];
    $data['pincode'] = $_POST['pincode'];
    $data['gender'] = $_POST['gender'];
    $data['dob'] = $_POST['dob'];
    $data['email'] = $_POST['email'];
    $data['user_id'] = getUser()['user_id'];    

    if($user->updateUser($data)){
      redirect('profile.php','Profile is Upadted ','success');
    }else{
      redirect('profile.php','Profile is not Update!!!','error');
    }



}else{


$template = new Template('template/profile1.php');

$user_id = getUser()['user_id'];


$template->user = $user->getUserInfo($user_id);

$template->total_posts = $user_posts->getCountTotalPosts($user_id);

$template->created_posts = $user_posts->getCountCreatedPosts($user_id);

$template->applied_posts = $user_posts->getCountAppliedPosts($user_id);

$template->active_posts = $user_posts->getCountActivePosts($user_id);

$template->completed_posts = $user_posts->getCountCompletedPosts($user_id);

$template->user_reviews = $feedback->getUserFeedback($user_id);


echo $template;

}
}else{
      redirect('index.php','','');  
}
?>