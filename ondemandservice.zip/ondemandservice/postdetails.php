<?php require('core/init.php') ?>

<?php
if(isLoggedIN()){

$user = new User(); 
$post = new Post();
$poststatus = new PostStatus();
$template = new Template('template/postdetails.php');
$feedback = new Feedback();

$u_id = $_SESSION['u_id'];
$p_id = $_SESSION['id'];


$user_id = getUser()['user_id'];
$template->user = $user->getUserInfo($user_id);


$template->seeker = $user->getUserInfo($u_id);

$template->post = $post->getPostDetails($p_id);
$template->poststatus = $poststatus->getAppliedPostStatus($p_id);

$template->poststart = $poststatus->checkPostStart($p_id);
$template->postcompletion = $poststatus->checkPostCompletion($p_id);

$template->checkproviderFeed = $feedback->checkProviderFeedback($user_id,$p_id);

 if(isset($_POST['feedback_posts'])){
  $data=array();
  $data['f_type'] = 'P';
  $data['rating'] = $_POST['rateno'];
  $data['comments'] = $_POST['comments'];
  $data['seeker'] = $u_id;
  $data['provider'] = getUser()['user_id'];  
  $data['p_id'] = $p_id;

  if($feedback->feedback($data)){
    redirect('postdetails.php',"Thank You for feedback!!!",'success');
    }else{
      redirect('postdetails.php','Error !!','error');
    }
      
 }



echo $template;
}else{
      redirect('index.php','','');  
}
?>