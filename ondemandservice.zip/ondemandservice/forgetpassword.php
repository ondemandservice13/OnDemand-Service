<?php require('core/init.php') ?>


<?php
$user = new User();

if(isset($_POST['forgetpass'])){

$email = $_POST['email'];

$userInfo = $user->getUserByEmail($email);

if($userInfo){
$otp = mt_rand(1000,9999);
$user_id = $userInfo->u_id;
if($user->forgotPassword($user_id,$otp)){
forgotpassword($email,$user_id,$otp);
}
}else{
  redirect('forgetpassword.php','please use registered email','error');
}

}

$template = new Template('template/forgetpassword.php');

echo $template;

?>