
<?php
 
// Create the Transport
$transport = (new Swift_SmtpTransport('smtp.gmail.com', 465,'ssl'))
  ->setUsername('ondemandservice13@gmail.com')
  ->setPassword('Devki@407')
;

// Create the Mailer using your created Transport
$mailer = new Swift_Mailer($transport);

		function emailVerification($userEmail,$user_id){
			global $mailer;
   
			$body= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Verify Email</title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                      Thank you for sign up on our website. Plese click on the link below 
                      to verify your email.
                  </p>
                  <a href ="http://localhost:80/ondemandservice/dbhelper.php?u_id='.$user_id.'&a=e">
                  Verify your email
                  </a>
                </div>
              </body>
              </html>';

                $message = (new Swift_Message('Verify Your Email !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($userEmail)
                 ->setBody($body,'text/html')
                 ;

          // Send the message
          $result = $mailer->send($message);
          } 

    function forgotpassword($userEmail,$user_id,$otp){
      global $mailer;
   
      $body= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Password Recovery</title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                    Plese click on the link below to verify your email for password recovery.
                  </p>
                  <a href ="http://localhost:80/ondemandservice/dbhelper.php?u_id='.$user_id.'&otp='.$otp.'&a=f">
                  Verify your email
                  </a>
                </div>
              </body>
              </html>';

                $message = (new Swift_Message('Password Recovery !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($userEmail)
                 ->setBody($body,'text/html')
                 ;

          // Send the message
          $result = $mailer->send($message);
          } 

          function enquiryForm($customerEmail,$customerName,$message){
      global $mailer;
   
      $body= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Customer Enquiry</title>
              </head>
              <body>
                <div class="wrapper">
                  <br>
                  <div style="margin-left:100px;">
                  <h2>Customer Enquiry</h2>
                  <h3>Name  : '.$customerName.'</h3>
                  <h3>Email : '.$customerEmail.'</h3>
                  <p stlye="font-size:15px;">
                    '.$message.'
                  </p>
                  </center>
                </div>
              </body>
              </html>';

                $message = (new Swift_Message('Customer Enquiry !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo('ondemandservice13@gmail.com')
                 ->setBody($body,'text/html')
                 ;

          // Send the message
          $result = $mailer->send($message);
          } 

?>