
<?php
 
 // Create the Transport
$transport = (new Swift_SmtpTransport('smtp.gmail.com', 465,'ssl'))
  ->setUsername('ondemandservice13@gmail.com')
  ->setPassword('Devki@407')
;

// Create the Mailer using your created Transport
$mailer = new Swift_Mailer($transport);

		function applyToPost($data){
			global $mailer;
      $applyby = $data['applyby'];
      $p_title = $data['p_title'];
      $p_id  = $data['p_id'];
      $user_id = $data['user_id'];
      $userEmail = $data['email'];
   
      $body= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Seeker Apply to Your Post</title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                      '.$applyby.' apply to your '.$p_title.' post.
                  </p>
                  <a href ="http://localhost:80/ondemandservice/dbhelper.php?id='.$p_id.'&u_id='.$user_id.'&a=u">
                  click here for more details.
                  </a>
                </div>
              </body>
              </html>';

                $message = (new Swift_Message('Apply to your post !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($userEmail)
                 ->setBody($body,'text/html')
                 ;

          // Send the message
          $result = $mailer->send($message);

          } 

          function acceptPostSeeker($data){
      global $mailer;
      $creator = $data['creator'];
      $p_title = $data['p_title'];
      $p_id  = $data['p_id'];
      $userEmail = $data['email'];
   
      $body= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Seeker Acceptance</title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                      '.$creator.' select you for '.$p_title.' job.
                  </p>
                  <a href ="http://localhost:80/ondemandservice/findpostdetails.php?id='.$p_id.'">
                  click here for more details.
                  </a>
                </div>
              </body>
              </html>';

                $message = (new Swift_Message('Seeker Confirmation !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($userEmail)
                 ->setBody($body,'text/html')
                 ;

          // Send the message
          $result = $mailer->send($message);

          } 

          function startJob($data){
      global $mailer;
      $applyby = $data['applyby'];
      $p_title = $data['p_title'];
      $p_id  = $data['p_id'];
      $user_id = $data['user_id'];
      $userEmail = $data['email'];
   
      $body= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Seeker Started Your Job</title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                      '.$applyby.' started your job of '.$p_title.'.
                  </p>
                  <a href ="http://localhost:80/ondemandservice/dbhelper.php?id='.$p_id.'&u_id='.$user_id.'&a=u">
                  click here for more details.
                  </a>
                </div>
              </body>
              </html>';

                $message = (new Swift_Message('Seeker Started Your Job !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($userEmail)
                 ->setBody($body,'text/html')
                 ;

          // Send the message
          $result = $mailer->send($message);

          }

          function jobDone($data){
      global $mailer;
      
      $p_title = $data['p_title'];
      $p_id  = $data['p_id'];
      $SeekerEmail = $data['s_email'];      
      $ProviderEmail = $data['p_email'];
      $user_id = $data['user_id'];
   
      $SeekerBody= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Job Completion </title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                      Your '.$p_title.' job is done. Thank you for using our website. 
                  </p>
                  <a href ="http://localhost:80/ondemandservice/findpostdetails.php?id='.$p_id.'">
                  click here for more details.
                  </a>
                </div>
              </body>
              </html>';

      $ProviderBody= '<!DOCTYPE html>
              <html lang="en">
              <head>
                  <title>Job Completion</title>
              </head>
              <body>
                <div class="wrapper">
                  <p>
                      Your '.$p_title.' job is done. Thank you for using our website. 
                  </p>
                  <a href ="http://localhost:80/ondemandservice/dbhelper.php?id='.$p_id.'&u_id='.$user_id.'&a=u">
                  click here for more details.
                  </a>
                </div>
              </body>
              </html>';        

                $message1 = (new Swift_Message('Job Completion !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($ProviderEmail)
                 ->setBody($ProviderBody,'text/html')
                 ;
          // Send the message
          $result = $mailer->send($message1);

                 $message2 = (new Swift_Message('Job Completion !'))
                 ->setFrom('ondemandservice13@gmail.com')
                 ->setTo($SeekerEmail)
                 ->setBody($SeekerBody,'text/html')
                 ;
          // Send the message
          $result = $mailer->send($message2);

          } 

?>