-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2020 at 09:12 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ondemandservice`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `f_id` int(3) NOT NULL,
  `p_id` int(5) NOT NULL,
  `f_type` varchar(15) NOT NULL,
  `provider` int(5) NOT NULL,
  `seeker` int(5) NOT NULL,
  `comments` varchar(500) NOT NULL,
  `rating` int(3) NOT NULL,
  `f_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`f_id`, `p_id`, `f_type`, `provider`, `seeker`, `comments`, `rating`, `f_date`) VALUES
(2, 10, 'S', 4, 1, 'great', 4, '2020-04-12 00:00:00'),
(5, 10, 'P', 4, 1, 'great', 4, '2020-04-12 00:00:00'),
(6, 1, 'S', 1, 2, 'nice !!!', 4, '2020-04-12 00:00:00'),
(7, 1, 'P', 1, 2, 'good work', 4, '2020-04-12 00:00:00'),
(8, 2, 'P', 2, 1, 'greate work', 5, '2020-04-19 00:00:00'),
(9, 2, 'S', 2, 1, 'nice work', 4, '2020-04-19 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `forgotpass`
--

CREATE TABLE `forgotpass` (
  `f_id` int(5) NOT NULL,
  `u_id` int(5) NOT NULL,
  `otp` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `p_id` int(3) NOT NULL,
  `p_title` varchar(50) NOT NULL,
  `p_desc` varchar(200) NOT NULL,
  `loc` varchar(50) NOT NULL,
  `stipend` int(10) NOT NULL,
  `provider` int(10) NOT NULL,
  `c_date` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`p_id`, `p_title`, `p_desc`, `loc`, `stipend`, `provider`, `c_date`) VALUES
(1, 'Delivery', 'deliver something to someone', 'Devky recidency,wagholi pune', 100, 1, '2020-03-13 00:00:00'),
(2, 'Baby sitting', 'taking care baby for 2 hrs', 'wagholi pune', 250, 2, '2020-03-13 00:00:00'),
(3, 'Baby sitting', 'taking care of baby', 'Devky recidency,wagholi pune', 500, 1, '2020-03-15 00:00:00'),
(4, 'Car Wash', 'washing car', 'Kamthe House, Phursungi', 300, 3, '2020-03-22 00:00:00'),
(9, 'gardaning', 'cutting grass', 'wagholi pune', 300, 3, '2020-03-23 00:00:00'),
(10, 'grossary shoping', 'bye some items ', 'katraj pune', 100, 4, '2020-03-28 00:00:00'),
(13, 'Baby sitting', 'aaaa', 'Devky recidency,wagholi pune', 250, 1, '2020-03-28 00:00:00'),
(14, 'grossary shoping', 'shop some grosarry', 'Sawantwadi', 50, 2, '2020-03-28 00:00:00'),
(15, 'Pick up', 'Picking up at 4 pm form bjs to devki', 'Devky recidency,wagholi pune', 100, 1, '2020-04-05 00:00:00'),
(16, 'Pick up', 'Pick up from bjs ', 'Devky recidency,wagholi pune', 100, 5, '2020-04-05 00:00:00'),
(17, 'Delivery', 'deliver some thing', 'katraj pune', 50, 5, '2020-04-05 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `poststatus`
--

CREATE TABLE `poststatus` (
  `id` int(5) NOT NULL,
  `p_id` int(5) NOT NULL,
  `creator` int(5) NOT NULL,
  `applyby` int(11) DEFAULT NULL,
  `apply_date` datetime DEFAULT current_timestamp(),
  `accept_date` date DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `completion_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `poststatus`
--

INSERT INTO `poststatus` (`id`, `p_id`, `creator`, `applyby`, `apply_date`, `accept_date`, `start_date`, `completion_date`) VALUES
(1, 1, 1, 2, '2020-03-29 00:00:00', '2020-03-29', '2020-03-29', '2020-03-29'),
(2, 2, 2, 1, '2020-03-30 00:00:00', '2020-03-30', '2020-03-30', '2020-04-19'),
(4, 4, 3, 5, '2020-04-05 00:00:00', '2020-04-05', '2020-04-05', '2020-04-05'),
(5, 10, 4, 1, '2020-04-11 00:00:00', '2020-04-11', '2020-04-11', '2020-04-11'),
(7, 9, 3, 2, '2020-04-19 00:00:00', '2020-04-19', NULL, NULL),
(9, 16, 5, 1, '2020-09-08 21:55:40', NULL, NULL, NULL),
(11, 17, 5, 2, '2020-09-08 22:00:26', '2020-09-08', NULL, NULL),
(12, 3, 1, 2, '2020-09-09 16:27:40', '2020-09-09', NULL, NULL),
(13, 14, 2, 1, '2020-09-09 18:47:57', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_id` int(3) NOT NULL,
  `firstName` varchar(15) NOT NULL,
  `lastName` varchar(15) NOT NULL,
  `mobile` bigint(10) NOT NULL,
  `contry` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `pincode` int(5) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `pimg` varchar(500) DEFAULT NULL,
  `c_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_id`, `firstName`, `lastName`, `mobile`, `contry`, `state`, `district`, `city`, `address`, `pincode`, `dob`, `gender`, `email`, `pass`, `pimg`, `c_date`) VALUES
(1, 'Siddharth', 'Satardekar', 9876543210, 'India', 'Maharastra', 'Sindhudurg', 'Kudal', 'a.p kalpana appartment ,nabarwadi', 416520, '1998-06-19', 'Male', 's.m.satardekar98@gmail.com', '698d51a19d8a121ce581499d7b701668', 'thFJSNM9V5.jpg', '2020-03-13 00:00:00'),
(2, 'Shubham', 'Narvekar', 1234567890, 'india', 'Maharastra', 'Sindhudurg', '', 'a.p. sawantwadi', 0, '1998-12-11', 'Male', 's.snarvekar007@gmail.com', 'bcbe3365e6ac95ea2c0343a2395834dd', 'img_avatar.png', '2020-03-13 00:00:00'),
(3, 'Kirti', 'Kamthe', 192837465, 'india', 'Maharastra', 'Pune', '', 'A.P. Phursung', 0, '1997-09-18', 'Female', 'kirtikamthe1@gmail.com', '310dcbbf4cce62f762a2aaa148d556bd', NULL, '2020-03-13 00:00:00'),
(4, 'saurabh', 'satardekar', 9420277473, 'india', 'Maharastra', 'Pune', '', 'A.P. Pune', 0, '1996-10-08', 'Male', 'saurabhsatardekar@gmail.com', '550a141f12de6341fba65b0ad0433500', NULL, '2020-03-28 00:00:00'),
(5, 'Pramod', 'Patil', 9128187298, 'india', 'Maharastra', 'Sindhudurg', '', 'At Pt. kankavali', 0, '1998-07-02', 'Male', 'pramodpatil1242@gmail.com', '15de21c670ae7c3f6f3f1f37029303c9', NULL, '2020-04-05 00:00:00'),
(6, 'Gopal', 'Hodavdekar', 8967452310, 'India', 'Maharastra', 'Sindhudurg', 'zarap', 'Hodavde', 416509, '1998-07-25', 'Male', 'gopalhodavdekar@gmail.com', 'fae0b27c451c728867a567e8c1bb4e53', NULL, '2020-04-18 00:00:00'),
(7, 'Subhash', 'Toke', 9922625209, 'India', 'Maharashtra', 'Pune', 'KHED', 'A.P.KADUS(TOKEWADI),TAL.KHED,DIST.PUNE 412404', 412404, '0000-00-00', 'Male', 'subhashtoke551@gmail.com', 'f1c1592588411002af340cbaedd6fc33', NULL, '2020-04-18 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `forgotpass`
--
ALTER TABLE `forgotpass`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `poststatus`
--
ALTER TABLE `poststatus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `f_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `forgotpass`
--
ALTER TABLE `forgotpass`
  MODIFY `f_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `p_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `poststatus`
--
ALTER TABLE `poststatus`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `u_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
