<?php

define("db_host","localhost");
define("db_user","root");
define("db_pass","");
define("db_name","ondemandservice");

define("SITE_TITLE", "ON DEMAND SERVICE");

define('BASE_URI','http://'.$_SERVER['SERVER_NAME'].'/ondemandservice/');


?>