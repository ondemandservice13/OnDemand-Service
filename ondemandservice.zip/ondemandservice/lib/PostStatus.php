<?php 

class PostStatus{

private $db;

	public function __construct(){
		  $this->db = new Database();
	}

	
	public function register($data){

		$this->db->query('INSERT INTO poststatus (p_id,creator,applyby) VALUES(:p_id,:creator,:user_id)');

		$this->db->bind(':p_id',$data['p_id']);
		$this->db->bind(':creator',$data['creator']);
		$this->db->bind(':user_id',$data['user_id']);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

	
	public function getAppliedPostStatus($p_id){
 	$this->db->query("SELECT * FROM poststatus as p join user as u on u.u_id = p.applyby  WHERE p_id = :p_id ");
 	$this->db->bind(':p_id',$p_id);
	$result = $this->db->resultset();

 	return $result;


 	}

 	public function getCheckPostId($p_id,$user_id){
 	$this->db->query("SELECT * FROM poststatus WHERE p_id = :p_id and applyby = :user_id");
 	$this->db->bind(':p_id',$p_id);
 	$this->db->bind(':user_id',$user_id);

 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}

 	}

 	public function checkPostAcceptance($p_id,$user_id){
 	$this->db->query("SELECT * FROM poststatus WHERE p_id = :p_id and accept_date is not null");
 	$this->db->bind(':p_id',$p_id);
 	
 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}

 	}

 	public function checkPostCompletion($p_id){
 	$this->db->query("SELECT * FROM poststatus WHERE p_id = :p_id and completion_date is not null");
 	$this->db->bind(':p_id',$p_id);
 	
 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}

 	}
 	
 	public function checkPostStart($p_id){
 	$this->db->query("SELECT * FROM poststatus WHERE p_id = :p_id and start_date is not null");
 	$this->db->bind(':p_id',$p_id);
 	
 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}

 	}


 	public function confirmSeeker($u_id,$p_id){
 	$this->db->query("UPDATE poststatus set accept_date = :date_c WHERE p_id = :p_id and applyby = :u_id ");
 	$this->db->bind(':p_id',$p_id);
 	$this->db->bind(':u_id',$u_id);
 	$this->db->bind(':date_c',date("Y-m-d"));
 	
	if($this->db->execute()){
			return true;
		}else{
			return false;
		}
 	} 

 	public function updateStartDate($data){
 	$this->db->query("UPDATE poststatus set start_date = :date_c WHERE p_id = :p_id and applyby = :u_id ");
 	$this->db->bind(':p_id',$data['p_id']);
 	$this->db->bind(':u_id',$data['user_id']);
 	$this->db->bind(':date_c',date("Y-m-d"));
 	
	if($this->db->execute()){
			return true;
		}else{
			return false;
		}
 	}   
	public function updateCompletionDate($u_id,$p_id){
 	$this->db->query("UPDATE poststatus set completion_date = :date_c WHERE p_id = :p_id and applyby = :u_id ");
 	$this->db->bind(':p_id',$p_id);
 	$this->db->bind(':u_id',$u_id);
 	$this->db->bind(':date_c',date("Y-m-d"));
 	
	if($this->db->execute()){
			return true;
		}else{
			return false;
		}
 	}  

 	public function userAppliedPostStatus($p_id,$u_id){
 	$this->db->query("SELECT * FROM poststatus WHERE p_id = :p_id and applyby = :u_id ");
 	$this->db->bind(':p_id',$p_id);
 	$this->db->bind(':u_id',$u_id);
 	
 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}

 	}  



 	public function deleteSeeker($u_id,$p_id){
 	$this->db->query("DELETE FROM poststatus WHERE p_id = :p_id and applyby != :u_id ");
 	$this->db->bind(':p_id',$p_id);
 	$this->db->bind(':u_id',$u_id);
 	
	if($this->db->execute()){
			return true;
		}else{
			return false;
		}
 	} 





 }

 ?>