<?php 

class User{

private $db;

	public function __construct(){
		  $this->db = new Database();
	}

	public function checkEmail($email){

		$this->db->query("SELECT email FROM user WHERE email = :email");

		$this->db->bind(':email',$email);
		
		$row = $this->db->single();

		if($this->db->rowCount() > 0){
			
			return false;
		}else{
			return true;
		}
	}

	public function register($data){

		$this->db->query('INSERT INTO user (firstName,lastName,mobile,contry,state,district,city,address,pincode,dob,gender,email,pass) VALUES(:firstName,:lastName,:mobile,:contry,:state,:district,:city,:address,:pincode,:dob,:gender,:email,:pass)');

		$this->db->bind(':firstName',$data['fname']);
		$this->db->bind(':lastName',$data['lname']);
		$this->db->bind(':mobile',$data['phone']);
		$this->db->bind(':contry',$data['contry']);
		$this->db->bind(':state',$data['state']);
		$this->db->bind(':district',$data['district']);
		$this->db->bind(':city',$data['city']);
		$this->db->bind(':address',$data['address']);
		$this->db->bind(':pincode',$data['pincode']);
		$this->db->bind(':dob',$data['dob']);
		$this->db->bind(':gender',$data['gender']);
		$this->db->bind(':email',$data['email']);
		$this->db->bind(':pass',$data['pass']);
		$user = new User();
		     
		if($this->db->execute()){
			if($this->login($data)){
				return true;
			}else{
				return false;
			}
		}else{
			return false;
		}
	}

	public function updateUser($data){

		$this->db->query(' UPDATE user set firstName = :firstName , lastName = :lastName ,mobile = :mobile ,contry = :contry, state = :state, district= :district, city = :city, address = :address, pincode =:pincode ,dob = :dob ,gender = :gender ,email = :email  where u_id = :user_id');

		$this->db->bind(':firstName',$data['fname']);
		$this->db->bind(':lastName',$data['lname']);
		$this->db->bind(':mobile',$data['mobile']);
		$this->db->bind(':contry',$data['contry']);
		$this->db->bind(':state',$data['state']);
		$this->db->bind(':district',$data['district']);
		$this->db->bind(':city',$data['city']);
		$this->db->bind(':address',$data['address']);
		$this->db->bind(':pincode',$data['pincode']);
		$this->db->bind(':dob',$data['dob']);
		$this->db->bind(':gender',$data['gender']);
		$this->db->bind(':email',$data['email']);
		$this->db->bind(':user_id',$data['user_id']);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}
	public function imgUpload($name,$user_id){
		$this->db->query(' UPDATE user set pimg = :img where u_id = :user_id');

		$this->db->bind(':img',$name);
		$this->db->bind(':user_id',$user_id);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

	public function login($data){
		$this->db->query("SELECT * FROM user WHERE email = :email AND pass = :pass");

		$this->db->bind(':email', $data['email']);
		$this->db->bind(':pass', $data['pass']);


		$row = $this->db->single();

		if($this->db->rowCount() > 0){
					$this->setUserData($row);
					return true;
		}else{
			return false;
		}
	}

	private function setUserData($row){
		$_SESSION['is_logged_in'] = true;
		$_SESSION['user_id'] = $row->u_id;
		$_SESSION['username'] = $row->email;
		$_SESSION['name'] = $row->firstName;
	}

	public function logOut(){
		unset($_SESSION['is_logged_in']);
		unset($_SESSION['user_id']);
		unset($_SESSION['username']);
		unset($_SESSION['name']);
		return true;
	}
 

 public function getUserInfo($user_id){
 	$this->db->query("SELECT * FROM user WHERE u_id = :user_id");
 	$this->db->bind(':user_id',$user_id);

 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
 }


 //*************** Verification and Password Recovery **************************************//

 	public function getUserByEmail($email){

		$this->db->query("SELECT * FROM user WHERE email = :email");

		$this->db->bind(':email',$email);
		
		$row = $this->db->single();

		if($this->db->rowCount() > 0){
			
			return $row;
		}else{
			return NULL;
		}
	}

		public function forgotPassword($user_id,$otp){

		$this->db->query('INSERT INTO forgotpass (u_id,otp) VALUES(:user_id ,:otp)');

		$this->db->bind(':user_id',$user_id);
		$this->db->bind(':otp',$otp);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

	public function updateVerification($user_id){
		$this->db->query(' UPDATE user set verify = 1 where u_id = :user_id');

		$this->db->bind(':user_id',$user_id);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

	public function checkOtp($data){

		$this->db->query("SELECT * FROM forgotpass WHERE u_id = :u_id and otp = :otp");

		$this->db->bind(':otp',$data['otp']);
		$this->db->bind(':u_id',$data['user_id']);
		
		$row = $this->db->single();

		if($this->db->rowCount() > 0){
			
			return true;
		}else{
			return false;
		}
	}


	public function updatePassword($pass,$u_id){
		$this->db->query(' UPDATE user set pass = :pass where u_id = :u_id');

		$this->db->bind(':u_id',$u_id);
		$this->db->bind(':pass',$pass);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

	public function deleteOtp($u_id){
		$this->db->query(' DELETE FROM forgotpass where u_id = :u_id');

		$this->db->bind(':u_id',$u_id);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}


 }


 ?>