<?php 

class Post{

private $db;

	public function __construct(){
		  $this->db = new Database();
	}

	public function register($data){

		$this->db->query('INSERT INTO posts (p_title,p_desc,loc,stipend,provider) VALUES(:postTitle,:descp,:loc,:price,:provider)');

		$this->db->bind(':postTitle',$data['post_title']);
		$this->db->bind(':descp',$data['post_disp']);
		$this->db->bind(':loc',$data['location']);
		$this->db->bind(':price',$data['stipend']);
		$this->db->bind(':provider',$data['user_id']);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

	public function poststatus($data){

		$this->db->query('INSERT INTO poststatus (p_id,creator,applyby) VALUES(:p_id,:creator,:user_id)');

		$this->db->bind(':p_id',$data['p_id']);
		$this->db->bind(':creator',$data['creator']);
		$this->db->bind(':user_id',$data['user_id']);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}


	public function allfindPosts($user_id){
 	$this->db->query("SELECT p.p_id,p_desc,p_title,stipend,loc,provider,p.c_date,ps.applyby,ps.accept_date FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider <> :user_id group by p.p_id order by p.c_date desc");
 	$this->db->bind(':user_id',$user_id);

 	$result = $this->db->resultset();

 	return $result;
 	}

 	public function getAllPosts($user_id){
 	$this->db->query("SELECT p.p_id,p_desc,p_title,stipend,loc,provider,p.c_date,applyby,ps.accept_date,completion_date FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider = :user_id or ps.applyby = :user_id group by p.p_id order by ps.apply_date desc, p.c_date desc");
 	$this->db->bind(':user_id',$user_id);

 	$result = $this->db->resultset();

 	return $result;
 	}

	public function getAllUserPosts($user_id){
 	$this->db->query("SELECT p.p_id,p_desc,p_title,stipend,loc,provider,p.c_date,applyby,ps.accept_date,completion_date FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider = :user_id and ps.completion_date IS null group by p.p_id order by p.c_date desc ");
 	$this->db->bind(':user_id',$user_id);

 	$result = $this->db->resultset();

 	return $result;
 	}

 	public function getAllAppliedPosts($user_id){
 	$this->db->query("SELECT p.p_id,p_desc,p_title,stipend,loc,provider,p.c_date,applyby,ps.accept_date,completion_date FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE ps.applyby = :user_id and ps.completion_date IS null order by ps.apply_date desc ");
 	$this->db->bind(':user_id',$user_id);

 	$result = $this->db->resultset();

 	return $result;
 	}

 	public function getAllCompletedPosts($user_id){
 	$this->db->query("SELECT p.p_id,p_desc,p_title,stipend,loc,provider,p.c_date,applyby,ps.accept_date,completion_date FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider = :user_id and ps.completion_date is not null or ps.applyby = :user_id and ps.completion_date is not null order by ps.completion_date desc");
 	$this->db->bind(':user_id',$user_id);

 	$result = $this->db->resultset();

 	return $result;
 	}


 	public function getPostDetails($p_id){
 	$this->db->query("SELECT * FROM posts as p join user as u on p.provider = u.u_id WHERE p_id = :p_id");
 	$this->db->bind(':p_id',$p_id);

 	$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}

 	}

 	public function deletePost($data){
		$this->db->query(' DELETE FROM posts where provider = :u_id and p_id = :p_id ');

		$this->db->bind(':u_id',$data['u_id']);
		$this->db->bind(':p_id',$data['p_id']);
		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

/****************COUNTING SQLS********************************************************************/

	public function getCountTotalPosts($user_id){
 	$this->db->query("SELECT count(p.p_id) as total FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider = :user_id or ps.applyby = :user_id ");
 	$this->db->bind(':user_id',$user_id);

		$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
 	}

 	public function getCountCreatedPosts($user_id){
 	$this->db->query("SELECT count(p.p_id) as total FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider = :user_id and ps.completion_date IS null ");
 	$this->db->bind(':user_id',$user_id);

 			$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
 	}

 	public function getCountAppliedPosts($user_id){
 	$this->db->query("SELECT count(p.p_id) as total FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE ps.applyby = :user_id and ps.start_date is null and ps.completion_date IS null ");
 	$this->db->bind(':user_id',$user_id);

 			$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
 	}

 	public function getCountCompletedPosts($user_id){
 	$this->db->query("SELECT count(p.p_id) as total FROM posts as p left join poststatus as ps on p.p_id = ps.p_id WHERE p.provider = :user_id and ps.completion_date is not null or ps.applyby = :user_id and ps.completion_date is not null");
 	$this->db->bind(':user_id',$user_id);

 			$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
 	}

 	public function getCountActivePosts($user_id){
 	$this->db->query("SELECT count(p.p_id) as total FROM posts as p join poststatus as ps on p.p_id = ps.p_id WHERE ps.applyby = :user_id 
 		and ps.start_date is not null and ps.completion_date is null or p.provider = :user_id and ps.start_date is not null and ps.completion_date is null ");
 	$this->db->bind(':user_id',$user_id);

 			$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
 	}	
	

 }

 ?>