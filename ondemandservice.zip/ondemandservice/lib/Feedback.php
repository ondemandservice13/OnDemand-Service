<?php 

class Feedback{

private $db;

	public function __construct(){
		  $this->db = new Database();
	}

		public function feedback($data){

		$this->db->query('INSERT INTO feedback (p_id,f_type,seeker,provider,comments,rating) VALUES(:p_id,:f_type,:seeker,:provider,:comments,:rating)');

		$this->db->bind(':p_id',$data['p_id']);
		$this->db->bind(':f_type',$data['f_type']);
		$this->db->bind(':seeker',$data['seeker']);
		$this->db->bind(':provider',$data['provider']);
		$this->db->bind(':comments',$data['comments']);
		$this->db->bind(':rating',$data['rating']);

		if($this->db->execute()){
			return true;
		}else{
			return false;
		}
	}

		public function checkSeekerFeedback($user_id,$p_id){
			$this->db->query("SELECT * FROM feedback as f join poststatus as ps on f.p_id = ps.p_id where  f.seeker = :user_id and f.f_type='S' And f.p_id = :p_id");
 			$this->db->bind(':user_id',$user_id);

 			$this->db->bind(':p_id',$p_id);

 			$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
		}

	public function checkProviderFeedback($user_id,$p_id){
			$this->db->query("SELECT * FROM feedback as f join poststatus as ps on f.p_id = ps.p_id where  f.provider = :user_id and f.f_type='P' And f.p_id = :p_id");
 			$this->db->bind(':user_id',$user_id);
 			$this->db->bind(':p_id',$p_id);

 			$row = $this->db->single();

 	if($this->db->rowCount() >0){
 		return $row;
 	}else{
 		return NUll;
 	}
		}

	public function getUserFeedback($user_id){
	$this->db->query("SELECT * from feedback where provider = :user_id AND f_type = 'S' or seeker = :user_id AND f_type = 'P' ");
 	$this->db->bind(':user_id',$user_id);

 	$result = $this->db->resultset();

 	return $result;
	}

}	