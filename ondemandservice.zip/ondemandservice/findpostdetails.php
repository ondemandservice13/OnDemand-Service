 <?php require('core/init.php') ?>

<?php
if(isLoggedIn()){
$user = new User();
$post = new Post();
$feedback = new Feedback();
$poststatus = new PostStatus();
$template = new Template('template/findpostdetails.php');

$user_id = getUser()['user_id'];

if(is_null($_SESSION['id'])){
$_SESSION['id'] = $_GET['id']; 
}

$p_id = $_SESSION['id'];

$template->user = $user->getUserInfo($user_id);
$template->post = $post->getPostDetails($p_id);
$template->poststatus = $poststatus->userAppliedPostStatus($p_id,$user_id);
$template->postidcheck = $poststatus->getCheckPostId($p_id,$user_id);
$template->postacceptance = $poststatus->checkPostAcceptance($p_id,$user_id);
$template->postcompletion = $poststatus->checkPostCompletion($p_id);

$template->poststart = $poststatus->checkPostStart($p_id);

if(isset($_POST['apply'])){
	$data = array();

    $data['p_id'] = $_SESSION['id'];
    $data['user_id'] = getUser()['user_id'];
    $data['creator'] = $template->post->provider;
    $data['email'] = $template->post->email;
    $data['p_title'] = $template->post->p_title;
    $data['applyby'] = getUser()['name'];
   
    if($poststatus->register($data)){
      applyToPost($data);
      redirect('findpostdetails.php','Applied !!!','success');
    }else{
      redirect('findpostdetails.php','Error!!!','error');
    }
}

if(isset($_POST['start'])){
	$data = array();

    $data['p_id'] = $_SESSION['id'];
    $data['user_id'] = getUser()['user_id'];
    $data['creator'] = $template->post->provider;
    $data['email'] = $template->post->email;
    $data['p_title'] = $template->post->p_title;
    $data['applyby'] = getUser()['name'];
   
    if($poststatus->updateStartDate($data)){
      startJob($data);
      redirect('findpostdetails.php',"let's start it !!!",'success');
    }else{
      redirect('findpostdetails.php','Error !!','error');
    }
}
$template->checkSeekerFeed = $feedback->checkSeekerFeedback($user_id,$p_id);

 if(isset($_POST['feedback_posts'])){
  $data=array();
  $data['f_type'] = 'S';
  $data['rating'] = $_POST['rateno'];
  $data['comments'] = $_POST['comments'];
  $data['seeker'] = getUser()['user_id'];
  $data['provider'] = $template->post->provider;
  $data['p_id'] = $p_id;

  if($feedback->feedback($data)){
    redirect('findpostdetails.php',"Thank You for feedback!!!",'success');
    }else{
      redirect('findpostdetails.php','Error !!','error');
    }
      
 }

 echo $template;

}else{
      redirect('index.php','','');  
}
?>