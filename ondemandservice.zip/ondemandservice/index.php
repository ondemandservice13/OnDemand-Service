<?php require('core/init.php') ?>

<?php


if(isset($_POST['enquiry'])){

$customerEmail = $_POST['Customer_email'];

$customerName = $_POST['Customer_name'];

$message = $_POST['comments'];

enquiryForm($customerEmail,$customerName,$message);

echo '<script>alert("Your query is sent. We will get back to you with in 24 hrs.")</script>'; 
}


$template = new Template('template/index.php');

echo $template;
?>