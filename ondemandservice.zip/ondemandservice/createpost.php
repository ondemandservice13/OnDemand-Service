<?php require('core/init.php') ?>

<?php


if(isLoggedIn()){
$template = new Template('template/createpost.php');

$user = new User();
$user_posts = new Post();

if(isset($_POST['create_posts'])){
    $data = array();

    $data['post_title'] = $_POST['post_title'];
    $data['post_disp'] = $_POST['post_disp'];
    $data['location'] = $_POST['location'];
    $data['stipend'] = $_POST['stipend'];
    $data['user_id'] = getUser()['user_id'];
    
    $post = new Post();
    if($post->register($data)){
      redirect('createpost.php','Post is created !!','success');
    }else{
      redirect('createpost.php','Wrong inputs !!','error');
    }

}
echo $template;

}else{
      redirect('index.php','','');  
}
?>